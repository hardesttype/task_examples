from typing import List, Tuple
import torch
import numpy as np
try:
    from tqdm.notebook import tqdm
except:
    pass


class BucketingSampler(torch.utils.data.Sampler):
    """
    A sampler for torch.utils.data.Dataset that sorts the data into buckets based on sequence lengths.
    The sampler is designed to reduce padding by grouping sequences with similar lengths together.
    This can help to improve training efficiency by reducing the amount of computation required for padding.
    
    Args:
        dataset (torch.utils.data.Dataset): A dataset object with a 'seq_lengths' attribute.
        bucket_boundaries (List[Tuple[int, int]]): A list of tuples specifying the minimum and maximum
                                                  sequence lengths for each bucket.
        shuffle (int, optional): Whether to shuffle the data within the buckets and the order of the buckets.
                                1 (Default) : Shuffle the data within the buckets and the order of the buckets
                                2           : Shuffle the data within the buckets
                                3           : Shuffle the order of the buckets
                                Other values: Do not shuffle
    """

    def __init__(
            self, 
            dataset: torch.utils.data.Dataset, 
            bucket_boundaries: List[Tuple[int, int]],
            shuffle: int = 1,
            random_seed: int = None,
            progress_bar: bool = True,
            seq_lengths: list = None,
            num_samples: int = None,
            replace: bool = False,
            sample_probs: List[float] = None,
        ):
        self.bucket_boundaries = bucket_boundaries
        self.progress_bar = progress_bar
        self.length = len(dataset)
        self.shuffle = shuffle
        self.random_seed = random_seed
        self.num_samples = num_samples
        self.replace = replace
        self.sample_probs = np.array(sample_probs) if sample_probs is not None else None
        
        if seq_lengths is not None:
            self.seq_lengths = seq_lengths
        else:
            self.seq_lengths = self._calc_seq_lengths(dataset)
            
        self.seq_lengths_buckets  = self._create_buckets(self.seq_lengths)
        
    def _calc_seq_lengths(self, dataset):
        if self.progress_bar:
            pbar = tqdm(total=len(dataset))
            pbar.set_description('Calculating lengths of samples in dataset')
            
        seq_lengths = []
        for feature_dict in dataset:
            seq_lengths.append(self._get_seq_len(feature_dict, dataset))
            if self.progress_bar:
                pbar.update(1)
                
        if self.progress_bar:        
            pbar.close()
        
        return seq_lengths

    def _create_buckets(self, seq_lengths):
        buckets = [[] for _ in range(len(self.bucket_boundaries))]
        
        for i, seq_len in enumerate(seq_lengths):
            for bucket_idx, (min_len, max_len) in enumerate(self.bucket_boundaries):
                if min_len <= seq_len <= max_len:
                    buckets[bucket_idx].append(i)
                    break
        return buckets

    def _shuffle_buckets(self):
        np.random.seed(self.random_seed)
        if self.shuffle in (1, 2):
            for bucket in self.seq_lengths_buckets:
                np.random.shuffle(bucket)
        if self.shuffle in (1, 3):
            np.random.shuffle(self.seq_lengths_buckets)

    def __iter__(self):
        self._shuffle_buckets()
        indices = [idx for bucket in self.seq_lengths_buckets for idx in bucket]
        if self.num_samples is None:
            yield from indices
        else:
            yield from self._sample(indices)
        
    def _sample(self, indices):
        np.random.seed(self.random_seed)
        sample_probs = self.sample_probs[indices] / self.sample_probs[indices].sum() if self.sample_probs is not None else None
        sample = np.random.choice(np.arange(len(indices)), self.num_samples, replace=self.replace, p=sample_probs)
        sample.sort()
        return np.array(indices)[sample].tolist()

    def __len__(self):
        return self.length if self.num_samples is None else self.num_samples
        
    def _get_seq_len(self, x, dataset):
        # multimodal
        if 'source_names' in dataset.__dict__.keys():
            total_len = 0
            for src_name in dataset.source_names:
                if src_name in x:
                    samples = x[src_name]
                    total_len += max(len(next(iter(s.values()))) for s in samples)
        else:
            samples = x
            total_len = max(len(next(iter(s.values()))) for s in samples)
            
        return total_len