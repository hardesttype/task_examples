import torch

from ptls.data_load.padded_batch import PaddedBatch


class RLayerNorm(torch.nn.Module):
    def __init__(self, num_features, bias=True):
        super().__init__()

        self.ln = torch.nn.LayerNorm(num_features, bias=True)

    def forward(self, v: PaddedBatch):
        x = v.payload
        B, T, H = x.size()  # B x T X H
        x = self.ln(x)
            
        return PaddedBatch(x, v.seq_lens)
