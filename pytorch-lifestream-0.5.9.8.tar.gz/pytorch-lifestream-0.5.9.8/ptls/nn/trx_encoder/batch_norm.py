import torch
import warnings

from ptls.data_load.padded_batch import PaddedBatch


class RBatchNorm(torch.nn.Module):
    def __init__(self, num_features, momentum=0.1, batch_size_1_error='raise', kind='2d'):
        super().__init__()

        self.bn = torch.nn.BatchNorm1d(num_features, momentum=momentum)
        self.batch_size_1_error = batch_size_1_error
        self.kind = kind

    def forward(self, v: PaddedBatch):
        x = v.payload
        B, T, H = x.size()  # B x T X H
        if self.kind == '2d':
            x = x.view(B * T, H)
        elif self.kind == '3d':
            x = x.transpose(1, 2)
        
        try:
            x = self.bn(x)
        except ValueError as ve:
            # ERROR still persists...
            if self.batch_size_1_error == 'raise':
                raise ve
                
            self.training = False
            x = self.bn(x)
            self.training = True
            
            if self.batch_size_1_error == 'warn':
                warnings.warn(repr(ve))
        except Exception as e:
            raise e

        if self.kind == '2d':
            x = x.view(B, T, H)
        elif self.kind == '3d':
            x = x.transpose(1, 2)
            
        return PaddedBatch(x, v.seq_lens)


class RBatchNormWithLens(torch.nn.Module):
    """
    The same as RBatchNorm, but ...
    Drop padded symbols (zeros) from batch when batch stat update
    """
    def __init__(self, num_features, momentum=0.1, batch_size_1_error='raise', kind='2d'):
        super().__init__()

        self.bn = torch.nn.BatchNorm1d(num_features, momentum=momentum)
        self.batch_size_1_error = batch_size_1_error
        self.kind = kind

    def forward(self, v: PaddedBatch):
        x = v.payload
        B, T, H = x.size()  # B x T X H

        mask = v.seq_len_mask.bool()
        x_new = x.clone()
        
        try:
            x_new[mask] = self.bn(x[mask])
        except ValueError as ve:
            if self.batch_size_1_error == 'raise':
                raise ve
                
            self.training = False
            x_new[mask] = self.bn(x[mask])
            self.training = True
            
            if self.batch_size_1_error == 'warn':
                warnings.warn(repr(ve))
        except Exception as e:
            raise e
            
        return PaddedBatch(x_new, v.seq_lens)
