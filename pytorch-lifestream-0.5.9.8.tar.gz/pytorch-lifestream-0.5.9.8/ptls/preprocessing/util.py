import os
import json
import pickle

import numpy as np
import pandas as pd

import torch
from torch.nn.utils.rnn import pack_sequence, unpack_sequence, PackedSequence

try:
    from tqdm.notebook import tqdm
except:
    pass


def pd_hist(data, name, bins=10):
    if data.dtype.kind == 'f':
        bins = np.linspace(data.min(), data.max(), bins + 1).round(1)
    elif np.percentile(data, 99) - data.min() > bins - 1:
        bins = np.linspace(data.min(), np.percentile(data, 99), bins).astype(int).tolist() + [int(data.max() + 1)]
    else:
        bins = np.arange(data.min(), data.max() + 2, 1).astype(int)
    df = pd.cut(data, bins, right=False).rename(name)
    df = df.to_frame().assign(cnt=1).groupby(name)[['cnt']].sum()
    df['% of total'] = df['cnt'] / df['cnt'].sum()
    return df


def update_with_target(features, df_target, col_id, col_target):
    d_clients = df_target.to_dict(orient='index')
    features = [
        dict([('target', d_clients.get(rec[col_id], {}).get(col_target))] + list(rec.items()))
        for rec in features
    ]
    return features
    

def get_names(feature_name):
    idx_del = feature_name.find('_')
    return feature_name[:idx_del], feature_name[idx_del + 1:]


def save_multimodal_sequential_data(
    data:        pd.DataFrame,
    path:        str,
    col_id:      str = None,
    col_target:  str = None,
    compression: str = 'snappy',
):    
    if not os.path.exists(path):
        os.makedirs(path)
    
    # Save id and target
    id_and_target = pd.DataFrame()
    for col in [col_id, col_target]:
        if col in data.columns:
            id_and_target[col] = data[col]
    
    if id_and_target.shape[0] > 0:
        id_and_target.to_parquet(os.path.join(path, 'id_and_target.parquet'), index=False, compression=compression)
    
    # Save other features
    feature_value_data = {}
    feature_value_batch_sizes = {}
    feature_value_indices = {}
    for col in data.columns:
        if col in [col_id, col_target]:
            continue
        
        ps = pack_sequence(data[col], enforce_sorted=False)
        
        source_name, feature_name_transform = get_names(col)
        if source_name not in feature_value_data:
            feature_value_data[source_name] = list()
        
        feature_value_data[source_name].append(pd.Series(ps.data, name=feature_name_transform))
        
        if source_name not in feature_value_batch_sizes:
            feature_value_batch_sizes[source_name] = pd.Series(ps.batch_sizes, name='batch_sizes').to_frame()
            
        if source_name not in feature_value_indices:
            feature_value_indices[source_name] = pd.DataFrame()
            feature_value_indices[source_name]['sorted_indices'] = ps.sorted_indices
            feature_value_indices[source_name]['unsorted_indices'] = ps.unsorted_indices
    
    for source_name, source_data in feature_value_data.items():
        source_path = os.path.join(path, source_name)
        if not os.path.exists(source_path):
            os.makedirs(source_path)
        
        source_data = pd.concat(source_data, axis=1)
        
        source_data.to_parquet(os.path.join(source_path, 'data.parquet'), index=False, compression=compression)
        
        feature_value_batch_sizes[source_name]\
        .to_parquet(os.path.join(source_path, 'batch_sizes.parquet'), index=False, compression=compression)
        
        feature_value_indices[source_name]\
        .to_parquet(os.path.join(source_path, 'indices.parquet'), index=False, compression=compression)
        
        
def read_multimodal_sequential_data(
    path:         str,
    col_id:       str = None,
    col_target:   str = None,
    progress_bar: bool = False,
):  
    id_and_target = pd.read_parquet(os.path.join(path, 'id_and_target.parquet'))
    
    source_names = [source_name for source_name in os.listdir(path) if source_name != 'id_and_target.parquet']
    
    output = [id_and_target]
    for source_name in source_names:
        data = pd.read_parquet(os.path.join(path, source_name, 'data.parquet'))
        batch_sizes = pd.read_parquet(os.path.join(path, source_name, 'batch_sizes.parquet'))['batch_sizes'].values
        indices = pd.read_parquet(os.path.join(path, source_name, 'indices.parquet'))
        sorted_indices, unsorted_indices = indices['sorted_indices'].values, indices['unsorted_indices'].values
        
        if progress_bar:
            pbar = tqdm(total = len(data.columns))
            pbar.set_description(f'Loading columns from {path}')
            
        for col in data.columns:
            ps = unpack_sequence(PackedSequence(
                torch.from_numpy(data[col].values),
                torch.from_numpy(batch_sizes), 
                torch.from_numpy(sorted_indices), 
                torch.from_numpy(unsorted_indices)
            ))
            
            output.append(pd.Series(ps, name=f'{source_name}_{col}'))
            pbar.update(1)
            
        if progress_bar:
            pbar.close()
        
        return pd.concat(output, axis=1)


def read_party_data(
    path:         str,
    sources:      list = None,
    col_id:       str = 'APPLICATION_NUMBER',
    col_target:   str = 'IS_MOB12_90P_FLG',
    splits:       list = None,
    verbose:      bool = True,
    progress_bar: bool = False,
):
    
    if verbose:
        print(f'Reading `preprocessors` and `feature_dtypes`...')
    
    with open(os.path.join(path, f'preprocessors.pkl'), 'rb') as f:
        preprocessors = pickle.load(f)
        
    with open(os.path.join(path, f'feature_dtypes.json'), 'r') as f:
        feature_dtypes = json.load(f)
    
    if col_target is not None:
        if verbose:
            print(f'Reading `target`...')
        
        target = pd.read_parquet(os.path.join(path, f'target.parquet'))
    else:
        target = None
    
    if sources is None:
        sources = [
            'internal',
            'loan'    ,
            'inquiry' ,
            'overview',
            'payments',
        ]
        
    if splits is None:
        splits = ['train', 'test', 'valid']
    
    data = {}
    for split in splits:
        if not os.path.exists(os.path.join(path, split)):
            print(f'Folder `{split}` does not exist!`')
            continue
        
        if verbose:
            print(f'Reading `{split}` data...')
        
        data[split] = {}
        
        if progress_bar:
            pbar = tqdm(total=len(sources))
        
        for name in sources:
            data[split][name] = read_multimodal_sequential_data(
                os.path.join(path, split, f'data_{name}'), 
                col_id=col_id,
                col_target=col_target,
            )
            
            if progress_bar:
                pbar.update(1)
        
        if progress_bar:
            pbar.close()
        
        if verbose:
            print(f'Merging `{split}` data...')
            
        joined_data = data[split][sources[0]]
        
        if progress_bar:
            pbar = tqdm(total=len(data[split]))
        
        for name, src in data[split].items():
            if name != sources[0]:
                joined_data =\
                joined_data.merge(src, how="outer", on=col_id)
            
            if progress_bar:
                pbar.update(1)
        
        if progress_bar:
            pbar.close()
        
        if verbose:
            print(f'Filling NA in `{split}` data...')
        
        joined_data = joined_data.applymap(lambda x: torch.tensor([]) if pd.isna(x) else x)
        
        if target is not None:
            if verbose:
                print(f'Adding target to `{split}` data...')
            
            joined_data = joined_data.merge(
                target[[col_id, col_target]], 
                how = 'inner'
            ).rename(columns = {col_target: f'target_{col_target}'})\
            .dropna(subset=[f'target_{col_target}']).reset_index(drop=True)\
            .astype({f'target_{col_target}': int})
            
        data[split] = joined_data
        
    return data, target, preprocessors, feature_dtypes


def tensor_to_list(
    x, 
    col_id='APPLICATION_NUMBER', 
    col_target='target_IS_MOB12_90P_FLG'
):
    if x.name not in [col_id, col_target]:
        return x.apply(lambda x: x.tolist())
    return x


def save_multimodal_sequential_data_to_jsons(
    path, 
    data, 
    col_id='APPLICATION_NUMBER', 
    col_target='target_IS_MOB12_90P_FLG',
    progress_bar=False,
    verbose=True,
):
    if verbose:
        print('Converting `data` to dict with lists...')
        
    if progress_bar:
        tqdm.pandas()
        data = data.progress_apply(
            tensor_to_list, axis=0, 
            col_id=col_id, col_target=col_target
        ).to_dict("records")
    else:
        data = data.apply(
            tensor_to_list, axis=0, 
            col_id=col_id, col_target=col_target
        ).to_dict("records")
        
    if verbose:
        print(f'Saving `data` to {path}...')
    
    if not os.path.exists(path):
        os.makedirs(path)
        
    if progress_bar:
        pbar = tqdm(total=len(data))
    
    for i in data:
        with open(os.path.join(path, i[col_id] + '.json'), 'w') as f:
            json.dump(i, f)
            
        if progress_bar:
            pbar.update(1)
    
    if progress_bar:
        pbar.close()
        
    if verbose:
        print(f'Finished saving `data`!')
