import pandas as pd
import numpy as np

from ptls.preprocessing.base import ColTransformer
from ptls.preprocessing.pandas.col_transformer import ColTransformerPandasMixin
from sklearn.preprocessing import QuantileTransformer

class QuantileScaler(ColTransformerPandasMixin, ColTransformer):
    """Calculate mean and st. dev. or min and max and scale numerical values

    Parameters
    ----------
    col_name_original:
        Source column name
    col_name_target:
        Target column name. Transformed column will be placed here
        If `col_name_target is None` then original column will be replaced by transformed values.
    is_drop_original_col:
        When target and original columns are different manage original col deletion.
    scale_type:
        Type of transformation.
        One of `standart_micro`, `standart_macro`, `minmax_micro`, `minmax_macro`
    log:
        Take ln(|x| + 1) * sign(x) if True
    col_id:
        Name of user id column. Used only to calculate macro statistics
    """
    def __init__(self,
                 col_name_original: str,
                 col_name_target: str = None,
                 is_drop_original_col: bool = True,
                 scale_type: str = 'standart_micro',
                 log: bool = False,
                 col_id: str = None,
                 ):
        super().__init__(
            col_name_original=col_name_original,
            col_name_target=col_name_target,
            is_drop_original_col=is_drop_original_col,
        )

        #self.scale_type = scale_type
        self.col_id = col_id
        self.log = log
        self.qt = QuantileTransformer(n_quantiles=10, random_state=42)
        #self.mean = None
        #self.std = None
        #self.min = None
        #self.max = None

    def fit(self, x: pd.DataFrame):
        super().fit(x)
        pd_col = x[[self.col_name_original]].astype(float)
        
        if self.log:
            pd_col = np.log1p(pd_col.abs()) * np.sign(pd_col)
        '''
        if self.scale_type in ['micro', 'standart_micro', 'standart']:
            self.mean = pd_col.mean()
            self.std = pd_col.std()

            self.std = self.std if self.std != 0 else 1
        elif self.scale_type in ['macro', 'standart_macro']:
            self.mean = pd_col.groupby(x[self.col_id]).mean().mean()
            self.std = pd_col.groupby(x[self.col_id]).std().mean()

            self.std = self.std if self.std != 0 else 1
        elif self.scale_type in ['minmax_micro', 'minmax']:
            self.min = pd_col.min()
            self.max = pd_col.max()
        elif self.scale_type in ['minmax_macro']:
            self.min = pd_col.groupby(x[self.col_id]).min().mean()
            self.max = pd_col.groupby(x[self.col_id]).max().mean()
        else:
            raise AttributeError(f'scale_type="{self.scale_type}". '
                                 'Choose one of `[standart_micro, standart_macro, minmax_micro, minmax_macro]`')
        '''
        self.qt = self.qt.fit(pd_col)
        return self

    def transform(self, x: pd.DataFrame):
        pd_col = x[[self.col_name_original]].astype(float)
        
        if self.log:
            pd_col = np.log1p(pd_col.abs()) * np.sign(pd_col)
        '''
        if self.scale_type in ['micro', 'standart_micro', 'standart', 'macro', 'standart_macro']:
            pd_col = ((pd_col - self.mean) / self.std).rename(self.col_name_target)
        elif self.scale_type in ['minmax_micro', 'minmax', 'minmax_macro']:
            pd_col = ((pd_col - self.min) / (self.max - self.min)).rename(self.col_name_target)
        '''
        pd_col = pd.DataFrame(self.qt.transform(pd_col), columns=pd_col.columns)    
        x = self.attach_column(x, pd_col[self.col_name_original])
        x = super().transform(x)
        return x
