import os
import glob

import pandas as pd
import numpy as np

from ml_model_monitor.visuals import *
from ml_model_monitor.statscalc import *
from ml_model_monitor.metrics import prauc1d, gini1d, psi1d_groupby


class MonthlyModelReport():
    def __init__(
        self, 
        model_name,
        model_id,
        save_dir = '.',
    ):
        self.model_name = model_name
        self.model_id = model_id
        
        self.save_dir = save_dir
        self.save_path = os.path.join(
            self.save_dir, 
            f'{self.model_id}_{self.model_name}', 
        )
        if not os.path.exists(self.save_path):
            os.mkdir(self.save_path)
    
    
    def execute(
        self,
        df,
        colmap: dict,
    ):
        
        # Добавляем риски в расчет
        df[colmap['TARGETS']] = df[colmap['TARGETS']].astype(float)
        risk = df[colmap['TARGETS']]\
        .apply(
            lambda x: x.notna().sum() * x * df[colmap['CONTRACT_AMT']] / (df[colmap['CONTRACT_AMT']] * x.notna()).sum()
            if x.notna().sum() != 0 else np.full(x.shape, np.nan)
        ).rename({t: 'RISK_' + t for t in colmap['TARGETS']}, axis=1)
        df = pd.concat([df, 100 * risk], axis=1)
        
        # Шаблон для отрисовки 2*2 + 3 = 7 графиков
        fig, axes = draw_template(
            shape=(5, 2), 
            multiax_rows=2, 
            title=self.model_name, 
            whspace=(0.25, 0.45)
        )
        
        ##### Общий мониторинг #####
        
        # Сюда пишем результаты, которые пойдут в Excel
        model_performance = dict()
        
        # Precision-Recall кривая
        scores_prauc, (precision, recall, pr_auc) = prauc1d(
            df[colmap['SCORE']], 
            df[colmap['TARGETS']],
            return_pr_curve=True
        )
        plot_pr_curve(precision, recall, scores_prauc, ax=axes[0])
        model_performance['PRAUC'] = scores_prauc
        
        # Общий GINI и ROC кривая
        scores_gini, (fpr, tpr, roc_auc) = gini1d(
            df[colmap['SCORE']], 
            df[colmap['TARGETS']],
            return_roc_curve=True
        )
        plot_roc_curve(fpr, tpr, scores_gini, ax=axes[1])
        model_performance['GINI'] = scores_gini
        
        # График среднего таргета в перцентильных группах скора
        model_performance['TARGET_SCORE_STATS'] =\
        mean_target_by_score(
            df[colmap['SCORE']], df[colmap['TARGETS']],
            bins = 20
        )
        
        plot_lines_and_bins(
            model_performance['TARGET_SCORE_STATS']['mean_target'], 
            model_performance['TARGET_SCORE_STATS']['total_cnt'], 
            ax = axes[2], 
            ylabels = ['Total count', 'Mean target'],
            title='Mean target in score percentile groups',
            annot_bins_offset=-120
        )
        
        # График среднего риска в перцентильных группах скора 
        model_performance['RISK_SCORE_STATS'] =\
        mean_target_by_score(
            df[colmap['SCORE']], df[risk.columns],
            bins = 20
        )
        
        plot_lines_and_bins(
            model_performance['RISK_SCORE_STATS']['mean_target'], 
            model_performance['RISK_SCORE_STATS']['total_cnt'], 
            ax = axes[3], 
            annot_bins_offset=-120
        )
        
        # Рассчитываем GINI по месяцам и продуктам
        all_target_stats = target_stats_groupby(
            df[colmap['SCORE']], df[colmap['TARGETS']],
            df[colmap['GENERATION']]
        )

        all_target_stats = all_target_stats.set_index(pd.MultiIndex.from_product(
            [all_target_stats.index, ['all']], 
            names=[all_target_stats.index.name, colmap['PRODUCT_GROUP']]
        ))

        prod_target_stats = target_stats_groupby(
            df[colmap['SCORE']], df[colmap['TARGETS']],
            df[[colmap['GENERATION'], colmap['PRODUCT_GROUP']]]
        )

        model_performance['TARGET_STATS'] =\
        pd.concat([all_target_stats, prod_target_stats]).sort_index()
        
        # Рассчитываем риски по месяцам и продуктам
        all_target_stats = target_stats_groupby(
            df[colmap['SCORE']], df[risk.columns],
            df[colmap['GENERATION']], score=None
        )

        all_target_stats = all_target_stats.set_index(pd.MultiIndex.from_product(
            [all_target_stats.index, ['all']], 
            names=[all_target_stats.index.name, colmap['PRODUCT_GROUP']]
        ))

        prod_target_stats = target_stats_groupby(
            df[colmap['SCORE']], df[risk.columns],
            df[[colmap['GENERATION'], colmap['PRODUCT_GROUP']]], score=None
        )

        model_performance['RISK_STATS'] =\
        pd.concat([all_target_stats, prod_target_stats]).sort_index()
        
        # График общего GINI по месяцам
        _data = model_performance['TARGET_STATS'].xs('all', level=colmap['PRODUCT_GROUP'])['GINI']
        plot_lines_and_bins(
            _data[_data > 0], # Отрисовываем только GINI > 0
            model_performance['TARGET_STATS'].xs('all', level=colmap['PRODUCT_GROUP'])\
            ['count'][colmap['TARGETS'][0]], 
            ax = axes[4], 
            title = 'GINI over time',
            legend_loc = 'upper right',
            ylabels = ['count SCORE', 'GINI'],
        )
        
        # График общего риска по месяцам
        plot_lines_and_bins(
            model_performance['RISK_STATS'].xs('all', level=colmap['PRODUCT_GROUP'])['mean'][risk.columns], 
            model_performance['RISK_STATS'].xs('all', level=colmap['PRODUCT_GROUP'])['count'][colmap['SCORE']], 
            ax = axes[5], 
            title = 'RISK over time',
            legend_loc = 'upper right',
            ylabels = ['count SCORE', 'mean RISK'],
        )
        
        # График кол-ва заявок, где модель принимала решения
        plot_lines_and_bins(
            df.groupby([colmap['CREATED_MONTH'], colmap['PRODUCT_GROUP']])[colmap['FINAL_FLAG']].sum()\
            .reset_index().pivot(
                index=colmap['CREATED_MONTH'], 
                columns=colmap['PRODUCT_GROUP'], 
                values=colmap['FINAL_FLAG']
            ), 
            df[colmap['SCORE']].groupby(df[colmap['CREATED_MONTH']]).count(), 
            ax = axes[6], 
            title = 'Count score and final flag',
            legend_loc = 'upper right',
            legend_title='sum FINAL_FLAG for:',
            ylabels = ['count SCORE', 'sum FINAL_FLAG'],
            fmt=[0, 3],
        )
        
        plt.savefig(
            os.path.join(self.save_path, 'GENERAL_PERFORMANCE.png'), 
            facecolor='white', bbox_inches='tight'
        )
        
        ##### Мониторинг PSI #####
        
        # Шаблон для отрисовки 5 графиков
        fig, axes = draw_template(
            shape=(5, 2), 
            multiax_rows=0, 
            title=self.model_name, 
            whspace=(0.25, 0.45)
        )
        
        # Берем выборку первых 100 тыс. контрактов как референсную
        ref_sample = df.sort_values(colmap['GENERATION']).iloc[:100000]\
        .sample(100000, replace=True)[colmap['SCORE']]
        
        # PSI по продуктам
        psi_values, ref, cur, bin_edges = psi1d_groupby(
            ref_sample, 
            df, 
            [colmap['GENERATION'], colmap['PRODUCT_GROUP']],
            bins=10,
            return_hist=True
        )
        
        # PSI в целом
        psi_values_all, ref_all, cur_all, bin_edges_all = psi1d_groupby(
            ref_sample, 
            df, 
            colmap['GENERATION'],
            bins=10,
            return_hist=True
        )
        
        # Соединяем PSI общий и по продуктам в 1 таблицу
        index_all = pd.MultiIndex.from_product([psi_values_all.index, ['all']])
        psi_values_all.index = index_all
        cur_all.index = index_all

        model_performance['PSI'] = psi_values.append(psi_values_all).sort_index()
        model_performance['SCORE_DISTRIBUTION'] = cur.append(cur_all).sort_index()
        model_performance['SCORE_BINS'] = pd.Series(bin_edges, name=colmap['SCORE'])
        
        product_groups = ['all'] + list(df[colmap['PRODUCT_GROUP']].unique())
        
        # Отрисовка графиков
        for ax, product in zip(axes, product_groups):
            plot_lines_and_bins(
                model_performance['SCORE_DISTRIBUTION']\
                .percent.xs(product, level=colmap['PRODUCT_GROUP']) * 100, 
                model_performance['SCORE_DISTRIBUTION']\
                ['count'].xs(product, level=colmap['PRODUCT_GROUP']).sum(axis=1),
                # model_performance['PSI'].xs(product, level=colmap['PRODUCT_GROUP']), 
                ax = ax, 
                title = f'Distribution of score for {product}',
                legend_loc = 'center right',
                bbox_to_anchor=(1.12, 0.5),
                ylabels = ['Bars: count', 'Lines: % of sample'],
                cmap='magma',
                annot=[True, True],
                fmt=[3, 3],
            )

        plt.savefig(
            os.path.join(self.save_path, 'PSI.png'), 
            facecolor='white', bbox_inches='tight'
        )
        
        ##### Мониторинг PSI (последние 60 дней) #####
        
        all_days = np.sort(df[colmap['CREATED_DATE']].unique())
        cur_days = all_days[-60:]
        ref_days = all_days[-90:-60]

        psi_values_all, ref_all, cur_all, bin_edges_all = psi1d_groupby(
            df[df[colmap['CREATED_DATE']].isin(ref_days)][colmap['SCORE']],
            df[df[colmap['CREATED_DATE']].isin(cur_days)].assign(**{colmap['PRODUCT_GROUP']: 'all'}),
            [colmap['CREATED_DATE'], colmap['PRODUCT_GROUP']], bins=10, return_hist=True
        )

        psi_values, ref, cur, bin_edges = psi1d_groupby(
            df[df[colmap['CREATED_DATE']].isin(ref_days)][colmap['SCORE']],
            df[df[colmap['CREATED_DATE']].isin(cur_days)],
            [colmap['CREATED_DATE'], colmap['PRODUCT_GROUP']], bins=10, return_hist=True
        )

        cur = cur_all.append(cur).sort_index()
        psi_values = psi_values_all.append(psi_values).sort_index()
        
        model_performance['DAILY_PSI'] = psi_values
        model_performance['DAILY_SCORE_DISTRIBUTION'] = cur
        model_performance['DAILY_SCORE_BINS'] = pd.Series(bin_edges, name=colmap['SCORE'])

        products = cur.percent.index.get_level_values(1).unique()
        fig, axes = draw_template((len(products), 1), 0, title=self.model_name)

        for product, ax in zip(products, axes):
            plot_lines_and_bins(
                cur.percent.xs(product, level=colmap['PRODUCT_GROUP'])[:-1],
                cur['count'].xs(product, level=colmap['PRODUCT_GROUP'])[:-1].sum(axis=1),
                # psi_values.xs(product, level=colmap['PRODUCT_GROUP'])[:-1],
                ax,
                annot=[False, True],
                cmap='magma',
                fmt=[0, 3],
                title=f'Current distribution for {product}',
                ylabels=['Bars: count', 'Lines: % of sample'],
                xticks_rotation=35
            )
        
        plt.savefig(
            os.path.join(self.save_path, 'DAILY_PSI.png'), 
            facecolor='white', bbox_inches='tight'
        )
        
        ##### Мониториг GINI #####
        
        # Шаблон для отрисовки 5 графиков
        fig, axes = draw_template(
            shape=(5, 2), 
            multiax_rows=0, 
            title=self.model_name, 
            whspace=(0.25, 0.45)
        )
        
        # Отрисовка графиков
        for ax, product in zip(axes, product_groups):
            _data = model_performance['TARGET_STATS'].xs(product, level=colmap['PRODUCT_GROUP'])['GINI']
            plot_lines_and_bins(
                _data[_data > 0], 
                model_performance['TARGET_STATS'].xs(product, level=colmap['PRODUCT_GROUP'])\
                ['count'][colmap['TARGETS'][0]], 
                ax = ax, 
                title = f'GINI for {product}',
                legend_loc = 'upper right',
                ylabels = ['count TARGET', 'GINI'],
            )
        
        plt.savefig(
            os.path.join(self.save_path, 'GINI.png'), 
            facecolor='white', bbox_inches='tight'
        )
        
        ##### Мониториг риска #####
        fig, axes = draw_template(
            shape=(5, 2), 
            multiax_rows=0, 
            title=self.model_name, 
            whspace=(0.25, 0.45)
        )

        for ax, product in zip(axes, product_groups):
            _data = model_performance['RISK_STATS'].xs(product, level=colmap['PRODUCT_GROUP'])\
            ['mean'][risk.columns]
            plot_lines_and_bins(
                _data[_data >= 0], 
                model_performance['TARGET_STATS'].xs(product, level=colmap['PRODUCT_GROUP'])\
                ['count'][colmap['SCORE']], 
                ax = ax, 
                title = f'RISK for {product}',
                legend_loc = 'upper right',
                ylabels = ['count SCORE', 'RISK'],
                # right_ylims=[0, None]
            )

        plt.savefig(
            os.path.join(self.save_path, 'RISK.png'), 
            facecolor='white', bbox_inches='tight'
        )
        
        with pd.ExcelWriter(
            os.path.join(self.save_path, f'{self.model_name}_MONTHLY_MONITORING.xlsx')
        ) as writer:
            for sheet_name, sheet_data in model_performance.items():
                sheet_data.to_excel(writer, sheet_name=sheet_name)
                
        return model_performance


class MonthlyModelComparison():
    def __init__(self, save_dir='./COMPARISON'):
        self.save_dir = save_dir
        
        if not os.path.exists(save_dir):
            os.mkdir(self.save_dir)
        
        if not os.path.exists(os.path.join(self.save_dir, 'GINI')):
            os.mkdir(os.path.join(self.save_dir, 'GINI'))
        
        if not os.path.exists(os.path.join(self.save_dir, 'RISK')):
            os.mkdir(os.path.join(self.save_dir, 'RISK'))
            
        if not os.path.exists(os.path.join(self.save_dir, 'PSI')):
            os.mkdir(os.path.join(self.save_dir, 'PSI'))
    
    def from_path(self, path='.'):

        model_reports = glob.glob(os.path.join(path, '*', '*_MONTHLY_MONITORING.xlsx'))
                
        self.comparison_report = {
            'TARGET_STATS': pd.DataFrame(),
            'RISK_STATS': pd.DataFrame(),
            'PSI': pd.DataFrame(),
        }
        
        for fp in model_reports:
            target_stats = pd.read_excel(fp, sheet_name='TARGET_STATS', index_col=[0, 1], header=[0, 1])
            target_stats = pd.concat(
                [target_stats], 
                keys=[fp.split('/')[-1].split('_MONTHLY_MONITORING.xlsx')[0]], names=['SCORING_MODEL']
            )
            self.comparison_report['TARGET_STATS'] = self.comparison_report['TARGET_STATS'].append(target_stats)
            
            risk_stats = pd.read_excel(fp, sheet_name='RISK_STATS', index_col=[0, 1], header=[0, 1])
            risk_stats = pd.concat(
                [risk_stats], 
                keys=[fp.split('/')[-1].split('_MONTHLY_MONITORING.xlsx')[0]], names=['SCORING_MODEL']
            )
            self.comparison_report['RISK_STATS'] = self.comparison_report['RISK_STATS'].append(risk_stats)
            
            psi_stats = pd.read_excel(fp, sheet_name='PSI', index_col=[0, 1], header=[0])
            psi_stats = pd.concat(
                [psi_stats], 
                keys=[fp.split('/')[-1].split('_MONTHLY_MONITORING.xlsx')[0]], names=['SCORING_MODEL']
            )
            self.comparison_report['PSI'] = self.comparison_report['PSI'].append(psi_stats)
        
        # self.comparison_report['TARGET_STATS'].drop([('GINI', 'GENERATION'), ('GINI', 'PRODUCT_GROUP')], axis=1, inplace=True)
        
        return self
        
    def execute(self, colmap, model_info):

        model_groups = model_info['GROUP'].unique()

        for target in colmap['TARGETS']:
            for product in colmap['PRODUCT_GROUPS']:

                fig, axs = draw_template((len(model_groups), 2), 0)

                for ax, model_group in zip(axs, model_groups):
                    model_names = model_info[model_info['GROUP'] == model_group]['SCORING_MODEL_NAME']

                    ##### GINI #####

                    data = self.comparison_report['TARGET_STATS']\
                    .xs(product, level=colmap['PRODUCT_GROUP'])['GINI'][target]\
                    .reset_index().pivot(
                        index = colmap['GENERATION'], 
                        columns='SCORING_MODEL', 
                        values=target
                    )

                    model_names = model_names[model_names.isin(data.columns)]
                    data = data[model_names]
                    data = data[data > 0]

                    data_count = self.comparison_report['TARGET_STATS']\
                    .xs(product, level=colmap['PRODUCT_GROUP'])['count'][target]\
                    .reset_index().pivot(
                        index = colmap['GENERATION'], 
                        columns = 'SCORING_MODEL', 
                        values = target
                    )[model_names].sum(axis=1)

                    plot_lines_and_bins(
                        data, 
                        data_count, 
                        title=f'{model_group}: {target} - {product} - GINI',
                        ylabels=['Total targets', 'GINI'],
                        ax=ax
                    )
                    
                save_path = os.path.join(
                    self.save_dir, 
                    'GINI', 
                    f'{product}_{target}_GINI.png'
                )

                plt.savefig(
                    save_path, 
                    facecolor='white', bbox_inches='tight'
                )
                
                fig, axs = draw_template((len(model_groups), 2), 0)
                for ax, model_group in zip(axs, model_groups):
                    model_names = model_info[model_info['GROUP'] == model_group]['SCORING_MODEL_NAME']

                    ##### RISK #####

                    data = self.comparison_report['RISK_STATS']\
                    .xs(product, level=colmap['PRODUCT_GROUP'])['mean']['RISK_' + target]\
                    .reset_index().pivot(
                        index = colmap['GENERATION'], 
                        columns='SCORING_MODEL', 
                        values='RISK_' + target
                    )

                    model_names = model_names[model_names.isin(data.columns)]
                    data = data[model_names]
                    data = data[data > 0]

                    data_count = self.comparison_report['RISK_STATS']\
                    .xs(product, level=colmap['PRODUCT_GROUP'])['count']['RISK_' + target]\
                    .reset_index().pivot(
                        index = colmap['GENERATION'], 
                        columns = 'SCORING_MODEL', 
                        values = 'RISK_' + target
                    )[model_names].sum(axis=1)

                    plot_lines_and_bins(
                        data, 
                        data_count, 
                        title=f'{model_group}: {target} - {product} - RISK',
                        ylabels=['Total apps', 'RISK'],
                        ax=ax
                    )
                    
                save_path = os.path.join(
                    self.save_dir, 
                    'RISK', 
                    f'{product}_{target}_RISK.png'
                )

                plt.savefig(
                    save_path, 
                    facecolor='white', bbox_inches='tight'
                )
        
        for product in colmap['PRODUCT_GROUPS']:
        
            fig, axs = draw_template((len(model_groups), 2), 0)
            
            for ax, model_group in zip(axs, model_groups):
                model_names = model_info[model_info['GROUP'] == model_group]['SCORING_MODEL_NAME']

                ##### PSI #####

                data = self.comparison_report['PSI']\
                .xs(product, level=colmap['PRODUCT_GROUP'])['psi']\
                .reset_index().pivot(
                    index = colmap['GENERATION'], 
                    columns='SCORING_MODEL', 
                    values='psi'
                )

                model_names = model_names[model_names.isin(data.columns)]
                data = data[model_names]
                data = data[data > 0]

                plot_lines_and_bins(
                    data, 
                    data.assign(COUNT = 0)['COUNT'], 
                    title=f'{model_group}: {product} - PSI',
                    ylabels=['Total apps', 'PSI'],
                    ax=ax
                )
                
            save_path = os.path.join(
                self.save_dir, 
                'PSI', 
                f'{product}_PSI.png'
            )

            plt.savefig(
                save_path, 
                facecolor='white', bbox_inches='tight'
            )
            
        return self.comparison_report