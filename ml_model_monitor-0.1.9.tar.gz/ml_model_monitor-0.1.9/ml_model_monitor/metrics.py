from typing import Tuple

import numpy as np
import pandas as pd

from sklearn.metrics import roc_curve, auc
from sklearn.metrics import precision_recall_curve, average_precision_score


def _psi(
    ref: pd.Series, 
    cur: pd.Series, 
    eps: float = 1e-6
):
    """Calculate the PSI based on reference and current data histograms
    Args:
        ref: % of records in each bucket for reference data
        cur: % of records in each bucket for current data
        eps: small value to prevent divizion by 0
    Returns:
        psi_value: the PSI
    """
        
    # Prevent log(0) or divizion by 0
    ref, cur = ref.copy(), cur.copy()
    ref[ref == 0] = eps
    cur[cur == 0] = eps
    
    '''
    # log(0) = 0
    # > negative values in sum
    log_diff = np.ma.log(ref.to_numpy()).filled(0) -\
          np.ma.log(cur.to_numpy()).filled(0)
    return np.sum(diff * log_diff)
    '''

    diff = ref - cur
    div = ref / cur

    return np.sum(diff * np.log(div))


def get_binned_data(
    reference_data:     pd.Series, 
    current_data:       pd.Series, 
    feature_type:       str, 
    bins:               int or str or list, 
    dropna:             bool = False,
    eps:                float = 1e-6,
    float_fmt:          int = 4,
    return_method_used: bool = False,
):
    """Split variable into `bins` buckets based on reference quantiles
    Args:
        reference_data: reference data
        current_data: current data
        feature_type: feature type - `num`, `cat` or `cnt` (not implemented)
        bins: if int - number of quantiles else - argument `bins` of np.histogram_bin_edges
        dropna: drop nan values or not
        eps: small value to prevent divizion by 0
        float_fmt: round float numbers in `reference_data` and `current_data` indices
        return_method: return string of what method was used
    Returns:
        ref_hist: % of records in each bucket for reference
        cur_hist: % of records in each bucket for current
        bin_edges: buckets
        
        if `return_method_used` is True additionally returns string:
            method_used: `num`, `cnt` or `cat`
    """
    if dropna:
        reference_data = reference_data.replace([np.inf, -np.inf], np.nan).dropna()
        current_data = current_data.replace([np.inf, -np.inf], np.nan).dropna()
    
    n_vals = reference_data.nunique() # Does not account for nan

    if feature_type == "num" and n_vals > 20 and reference_data.dtype in ('int', 'float'):
        
        method_used = 'num'
        
        if type(bins) is int:
            # Numeric values, percentile
            bin_edges = 100 * np.arange(0, bins + 1) / bins
            # Here pd.unique to drop duplicate intervals
            bin_edges = np.sort(pd.unique(
                np.nanpercentile(reference_data.replace([np.inf, -np.inf], np.nan), bin_edges)
            ))
            
        else:
            # Numeric values, other methods
            bin_edges = np.histogram_bin_edges(reference_data[~np.isnan(reference_data)], bins)
            
        if not dropna:
            # Maximum will be added to the training sample bin
            bin_edges[-1] = bin_edges[-1] + eps
            # Add nan and inf values
            bin_edges = np.concatenate([[-np.inf], bin_edges, [np.inf]])
        
        index = ['[{1:.{0}f}:{2:.{0}f})'.format(float_fmt, bin_edges[i], bin_edges[i+1]) 
                 for i in range(len(bin_edges) - 1)]
        index[-1] = '[{1:.{0}f}:{2:.{0}f}]'.format(float_fmt, bin_edges[-2], bin_edges[-1])
        
        ref_hist, bin_edges = np.histogram(reference_data, bin_edges)
        cur_hist, _ = np.histogram(current_data, bin_edges)
        
        ref_cnt = pd.Series(ref_hist, index=index, name='count')
        cur_cnt = pd.Series(cur_hist, index=index, name='count')
        
        if not dropna:
            bin_edges = np.concatenate([bin_edges, [np.nan]])
            ref_cnt[str(bin_edges[-1])] = reference_data.isna().sum()
            cur_cnt[str(bin_edges[-1])] = current_data.isna().sum()
        
        ref_perc = (ref_cnt / len(reference_data)).rename('percent')
        cur_perc = (cur_cnt / len(current_data)).rename('percent')
        
        ref_hist = pd.concat([ref_perc, ref_cnt], axis=1).rename_axis(reference_data.name)
        cur_hist = pd.concat([cur_perc, cur_cnt], axis=1).rename_axis(current_data.name)
        
    elif feature_type == 'cnt' and n_vals > 20 and reference_data.dtype in ('int', 'float'):
        # Numeric values, countable variables
        # Here we round values, so the intervals are integers
        
        method_used = 'cnt'
        
        raise NotImplementedError()

    else:
        # Categories
        
        method_used = 'cat'
        
        ref_cnt = reference_data.value_counts(dropna=dropna).rename('count')
        cur_cnt = current_data.value_counts(dropna=dropna).rename('count')
        
        ref_perc = (ref_cnt / len(reference_data)).rename('percent')
        cur_perc = (cur_cnt / len(current_data)).rename('percent')
        
        ref_hist = pd.concat([ref_perc, ref_cnt], axis=1).rename_axis(reference_data.name)
        cur_hist = pd.concat([cur_perc, cur_cnt], axis=1).rename_axis(current_data.name)
        
        # Returns CategoricalIndex here from version 0.0.4. Subject to test
        bin_edges = ref_hist.index.union(cur_hist.index).sort_values()

        if not bin_edges.isna().any() and not dropna:
            bin_edges = np.concatenate([bin_edges, [np.nan]])
            
        ref_hist, cur_hist = ref_hist.reindex(bin_edges).fillna(0.),\
                             cur_hist.reindex(bin_edges).fillna(0.)
    
    if return_method_used:
        return ref_hist, cur_hist, bin_edges, method_used
    
    return ref_hist, cur_hist, bin_edges


def psi1d(
    reference_data: pd.Series, 
    current_data:   pd.Series, 
    feature_type:   str = 'num',        # num, cat, cnt?
    bins:           int or str = 30,    # for num and cnt feature types
    eps:            float = 1e-6,       # prevent divizion by 0
    dropna:         bool = False,       # if True nan's are added to hist
    float_fmt:      int = 4,
    return_hist:    bool = False,
) -> pd.Series or Tuple[pd.Series, ...]:
    """Calculate the PSI
    Args:
        reference_data: reference data
        current_data: current data
        feature_type: feature type - `num`, `cat` or `cnt` (not implemented)
        bins: number of quantiles or `bins` argument of np.histogram_bin_edges
        eps: small value to prevent divizion by 0
        dropna: consider nan values in hist or not
        float_fmt: round float numbers in `reference_data` and `current_data` indices
        return_hist: additionally returns `reference_data` and `current_data` range values and bins
    Returns:
        if return_hist:
            psi_value: calculated PSI
            reference_hist: reference data histogram
            current_hist: current data histogram
            bin_edges: bin_edges or categories
        else:
            psi_value: calculated PSI
    """
    
    reference_hist, current_hist, bin_edges = get_binned_data(
        reference_data, current_data, 
        feature_type, bins, dropna, eps, float_fmt
    )
    
    psi_value = _psi(reference_hist.percent, current_hist.percent, eps)
    
    if return_hist:
        return psi_value, reference_hist, current_hist, bin_edges
    
    return psi_value


def psi1d_groupby(
    reference_data:       pd.Series, 
    current_data:         pd.DataFrame,
    current_groupby_cols: str or list,
    feature_type:         str = 'num',        # num, cat, cnt?
    bins:                 int or str = 30,    # for num and cnt feature types
    eps:                  float = 1e-6,       # prevent divizion by 0
    dropna:               bool = False,       # if True nan's are added to hist
    float_fmt:            int = 4,
    return_hist:          bool = False,
) -> pd.Series or Tuple[pd.Series, ...]:
    """Calculate the PSI of every group
    Args:
        reference_data: reference data
        current_data: current data with group columns
        current_groupby_cols: columns to groupby
        feature_type: feature type - `num`, `cat` or `cnt` (not implemented)
        bins: number of quantiles or `bins` argument of np.histogram_bin_edges
        eps: small value to prevent divizion by 0
        dropna: consider nan values in hist or not
        float_fmt: round float numbers in `reference_data` and `current_data` indices
        return_hist: additionally returns `reference_data` and `current_data` range values and bins
    Returns:
        if return_hist:
            psi_value: calculated PSI of every group
            reference_hist: reference data histogram
            current_hists: grouped current data histograms
            bin_edges: bin_edges or categories
        else:
            psi_value: calculated PSI
    """
    
    if type(current_groupby_cols) is str:
        current_groupby_cols = [current_groupby_cols]
    
    # Get reference_hist
    reference_hist, current_hist, bin_edges, method_used =\
    get_binned_data(
        reference_data, current_data[reference_data.name], 
        feature_type, bins, dropna, eps, float_fmt,
        return_method_used=True
    )
    
    if method_used == 'num':
        current_hists = current_data.groupby(current_groupby_cols)[reference_data.name]\
        .apply(lambda x: np.histogram(x, bins=bin_edges)[0])
        
        current_hists = pd.DataFrame.from_records(
            data = current_hists.values, 
            index = current_hists.index, 
            columns = reference_hist.index
        )
        
    elif method_used == 'cnt':
        raise NotImplementedError()
    else:
        current_hists = current_data.groupby(current_groupby_cols)[reference_data.name]\
        .value_counts(dropna=dropna).rename('count').reset_index()\
        .pivot(index=current_groupby_cols, columns=reference_data.name, values='count')
        # .apply(lambda x: x.value_counts(dropna=dropna).to_frame().T)
        
        # Correct index and columns names
        # idx2drop = np.arange(2*len(current_groupby_cols))[-len(current_groupby_cols):].tolist()
        # current_hists = current_hists.reset_index(level=idx2drop, drop=True)
        # current_hists = current_hists.reindex(columns = reference_hist.index)
    
    current_cnts = current_hists.reindex(columns=current_hist.index).fillna(0)
    current_percs = current_cnts.div(current_cnts.sum(axis=1), axis=0)
    
    psi_value = current_percs.apply(lambda x: _psi(reference_hist.percent, x, eps), axis=1).rename('psi')
    
    if return_hist:
        
        # Multiindex
        current_cnts.columns = pd.MultiIndex.from_product(
            [['count'], current_cnts.columns], names=['type', current_cnts.columns.name]
        )
        current_percs.columns = pd.MultiIndex.from_product(
            [['percent'], current_percs.columns], names=['type', current_percs.columns.name]
        )
        current_hists = pd.concat([current_cnts.astype(int), current_percs], axis=1)
        
        return psi_value, reference_hist, current_hists, bin_edges
    
    return psi_value


def psi1d_groupby_v1(
    reference_data:       pd.Series, 
    current_data:         pd.Series,
    by:                   pd.Series or pd.DataFrame,
    feature_type:         str = 'num',        # num, cat, cnt?
    bins:                 int or str = 30,    # for num and cnt feature types
    eps:                  float = 1e-6,       # prevent divizion by 0
    dropna:               bool = False,       # if True nan's are added to hist
    float_fmt:            int = 4,
    return_hist:          bool = False,
) -> pd.Series or Tuple[pd.Series, ...]:
    """Calculate the PSI of every group
    Args:
        reference_data: reference data
        current_data: current_data
        by: for `current_data`, same as `by` arg in pd.Series.groupby
        feature_type: feature type - `num`, `cat` or `cnt` (not implemented)
        bins: number of quantiles or `bins` argument of np.histogram_bin_edges
        eps: small value to prevent divizion by 0
        dropna: consider nan values in hist or not
    Returns:
        if return_hist:
            psi_value: calculated PSI of every group
            reference_hist: reference data histogram
            current_hists: grouped current data histograms
            bin_edges: bin_edges or categories
        else:
            psi_value: calculated PSI
    """
    
    # Get reference_hist
    reference_hist, current_hist, bin_edges, method_used =\
    get_binned_data(
        reference_data, current_data, 
        feature_type, bins, dropna, eps, float_fmt, 
        return_method_used=True
    )
    
    if method_used == 'num':
        current_hists = current_data.groupby(by)\
        .apply(lambda x: np.histogram(x, bins=bin_edges)[0])
        
        current_hists = pd.DataFrame.from_records(
            data = current_hists.values, 
            index = current_hists.index, 
            columns = reference_hist.index
        )
        
    elif method_used == 'cnt':
        raise NotImplementedError()
    else:
        current_hists = current_data.groupby(by)\
        .value_counts(dropna=dropna).rename('count').reset_index()\
        .pivot(index=current_groupby_cols, columns=reference_data.name, values='count')
    
    current_cnts = current_hists.reindex(columns=current_hist.index).fillna(0)
    current_percs = current_cnts.div(current_cnts.sum(axis=1), axis=0)
    
    psi_value = current_percs.apply(lambda x: _psi(reference_hist.percent, x, eps), axis=1).rename('psi')
    
    if return_hist:
        
        # Multiindex
        current_cnts.columns = pd.MultiIndex.from_product(
            [['count'], current_cnts.columns], names=['type', current_cnts.columns.name]
        )
        current_percs.columns = pd.MultiIndex.from_product(
            [['percent'], current_percs.columns], names=['type', current_percs.columns.name]
        )
        current_hists = pd.concat([current_cnts.astype(int), current_percs], axis=1)
        
        return psi_value, reference_hist, current_hists, bin_edges
    
    return psi_value


def gini1d(
    y_score:          pd.Series, 
    y_target:         pd.Series or pd.DataFrame,
    score:            str = 'GINI', # or roc
    multiplier:       float = 100,
    return_roc_curve: bool = False,
):
    """Calculate the GINI of `y_score` for `y_target` (can be DataFrame of targets)
    Args:
        y_score: series of score values
        y_target: series or dataframe of targets
        score: calculate `gini` or `roc` score
        multiplier: by what metric is multiplied
        return_roc_curve: additionally returns roc curve info
    Returns:
        if return_roc_curve:
            scores: calculated metric
            (fpr, tpr, roc_auc): roc curve info
        else:
            scores: calculated metric
    """
    
    if type(y_target) == pd.Series:
        y_target = y_target.to_frame()
    
    if len(y_target) == 0 or y_target.isna().all().all():
        scores = pd.Series(
            index=y_target.columns, 
            name=score.upper(), 
            dtype=np.float64
        )
        if return_roc_curve:
            empty = {k: np.array([]) for k in scores.index}
            return scores, (empty, empty, empty)
        
        return scores
    
    fpr = dict()
    tpr = dict()
    roc_auc = dict()
    for target in y_target:
        mask = y_target[target].isna()
        if (~mask).sum() == 0:
            # Если нет таргета - возвращаем пусто
            fpr[target], tpr[target], roc_auc[target] =\
            np.array([]), np.array([]), np.nan
        else:   
            fpr[target], tpr[target], _ = roc_curve(
                y_target.loc[~mask, target], 
                y_score.loc[~mask], pos_label = 1
            )
            roc_auc[target] = auc(fpr[target], tpr[target])
    
    scores = pd.Series(
        {
            target: (2 * roc_auc[target] - 1) * multiplier\
            if score.upper() == 'GINI'\
            else roc_auc[target]\
            for target in y_target
        },
        name=score.upper(), 
        dtype=np.float64
    )
    
    if return_roc_curve:
        return scores, (fpr, tpr, roc_auc)
    return scores


def prauc1d(
    y_score:          pd.Series, 
    y_target:         pd.Series or pd.DataFrame,
    score:            str = 'PRAUC', # or roc
    multiplier:       float = 100,
    return_pr_curve:  bool = False,
):
    """Calculate the PR-AUC of `y_score` for `y_target` (can be DataFrame of targets)
    Args:
        y_score: series of score values
        y_target: series or dataframe of targets
        score: calculate `prauc` score
        multiplier: by what metric is multiplied
        return_roc_curve: additionally returns PR curve info
    Returns:
        if return_roc_curve:
            scores: calculated metric
            (precision, recall, pr_auc): roc curve info
        else:
            scores: calculated metric
    """
    
    if type(y_target) == pd.Series:
        y_target = y_target.to_frame()
        
    if len(y_target) == 0 or y_target.isna().all().all():
        scores = pd.Series(
            index=y_target.columns, 
            name=score.upper(), 
            dtype=np.float64
        )
        if return_pr_curve:
            empty = {k: np.array([]) for k in scores.index}
            return scores, (empty, empty, empty)
        
        return scores
        
    precision = dict()
    recall = dict()
    pr_auc = dict()
    for target in y_target:
        mask = y_target[target].isna()
        if (~mask).sum() == 0:
            # Если нет таргета - возвращаем пусто
            precision[target], recall[target], pr_auc[target] =\
            np.array([]), np.array([]), np.nan
        else:   
            precision[target], recall[target], _ = precision_recall_curve(
                y_target.loc[~mask, target], 
                y_score.loc[~mask]
            )
            pr_auc[target] = average_precision_score(
                y_target.loc[~mask, target], y_score.loc[~mask])
    
    scores = pd.Series(
        {k: v * multiplier for k, v in pr_auc.items()},
        name=score.upper(), 
        dtype=np.float64
    )
    
    if return_pr_curve:
        return scores, (precision, recall, pr_auc)
    return scores
