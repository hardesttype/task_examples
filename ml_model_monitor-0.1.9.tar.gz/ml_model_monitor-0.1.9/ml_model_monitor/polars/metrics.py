from typing import Tuple, Union, Optional, List
import numpy as np
import polars as pl
from sklearn.metrics import roc_curve, auc, precision_recall_curve, average_precision_score

def _psi(ref: pl.Series, cur: pl.Series, eps: float = 1e-6) -> float:
    """Calculate the PSI based on reference and current data histograms."""
    ref = ref.to_numpy().copy()
    cur = cur.to_numpy().copy()
    
    # Replace zeros with eps to avoid division by zero or log(0)
    ref[ref == 0] = eps
    cur[cur == 0] = eps
    
    diff = ref - cur
    div = ref / cur
    return np.sum(diff * np.log(div))

def get_binned_data(
    reference_data: pl.Series,
    current_data: pl.Series,
    feature_type: str,
    bins: Union[int, str, List[float]],
    dropna: bool = False,
    eps: float = 1e-6,
    float_fmt: int = 4,
    return_method_used: bool = False,
) -> Union[Tuple[pl.DataFrame, pl.DataFrame, pl.Series], Tuple[pl.DataFrame, pl.DataFrame, pl.Series, str]]:
    """Split variable into bins/categories and compute histograms."""
    # Handle NaN and Inf
    ref_clean = reference_data
    cur_clean = current_data
    if dropna:
        ref_clean = ref_clean.filter(ref_clean.is_finite() & ref_clean.is_not_null())
        cur_clean = cur_clean.filter(cur_clean.is_finite() & cur_clean.is_not_null())
    
    n_vals = ref_clean.n_unique()
    method_used = 'cat'
    
    if feature_type == "num" and n_vals > 20 and ref_clean.dtype in (pl.Int64, pl.Int32, pl.Int16, pl.Int8, pl.UInt64, pl.UInt32, pl.UInt16, pl.UInt8, pl.Float64, pl.Float32):
        method_used = 'num'
        ref_np = ref_clean.to_numpy()
        cur_np = cur_clean.to_numpy()
        
        # Compute bin edges
        if isinstance(bins, int):
            quantiles = np.linspace(0, 100, bins + 1)
            bin_edges = np.unique(np.nanpercentile(ref_np, quantiles))
        else:
            bin_edges = np.histogram_bin_edges(ref_np, bins)
        
        if not dropna:
            bin_edges = np.concatenate([[-np.inf], bin_edges, [np.inf]])
            bin_edges[-2] += eps
        
        # Create bin labels
        labels = [
            f"[{bin_edges[i]:.{float_fmt}f},{bin_edges[i+1]:.{float_fmt}f})"
            for i in range(len(bin_edges) - 1)
        ]
        labels[-1] = labels[-1].replace(')', ']')
        
        # Compute histograms
        ref_hist, _ = np.histogram(ref_np, bin_edges)
        cur_hist, _ = np.histogram(cur_np, bin_edges)
        
        # Handle NaN counts if not dropping
        if not dropna:
            labels.append('nan')
            ref_nan_count = reference_data.is_null().sum()
            cur_nan_count = current_data.is_null().sum()
            ref_hist = np.append(ref_hist, ref_nan_count)
            cur_hist = np.append(cur_hist, cur_nan_count)
        
        # Create DataFrames
        ref_df = pl.DataFrame({
            "bin": labels,
            "count": ref_hist,
            "percent": ref_hist / len(reference_data)
        })
        cur_df = pl.DataFrame({
            "bin": labels,
            "count": cur_hist,
            "percent": cur_hist / len(current_data)
        })
        bin_edges_series = pl.Series("bin_edges", bin_edges)
        
    elif feature_type == 'cnt':
        raise NotImplementedError("Countable feature type not implemented.")
    else:
        # Categorical handling
        ref_counts = reference_data.value_counts().sort('count', descending=True)
        cur_counts = current_data.value_counts().sort('count', descending=True)
        
        # Align categories
        all_cats = pl.concat([ref_counts[reference_data.name], cur_counts[reference_data.name]]).unique(maintain_order=True)
        ref_counts = all_cats.to_frame().join(ref_counts, on=reference_data.name, how="left").fill_null(0)
        cur_counts = all_cats.to_frame().join(cur_counts, on=reference_data.name, how="left").fill_null(0)
        
        # Calculate percentages
        ref_percent = ref_counts["count"] / len(reference_data)
        cur_percent = cur_counts["count"] / len(current_data)
        
        ref_df = ref_counts.with_columns(percent=ref_percent)
        cur_df = cur_counts.with_columns(percent=cur_percent)
        bin_edges_series = all_cats
    
    if return_method_used:
        return ref_df, cur_df, bin_edges_series, method_used
    return ref_df, cur_df, bin_edges_series

def psi1d(
    reference_data: pl.Series,
    current_data: pl.Series,
    feature_type: str = 'num',
    bins: Union[int, str] = 30,
    eps: float = 1e-6,
    dropna: bool = False,
    float_fmt: int = 4,
    return_hist: bool = False,
) -> Union[float, Tuple[float, pl.DataFrame, pl.DataFrame, pl.Series]]:
    """Calculate PSI between reference and current data distributions."""
    ref_hist, cur_hist, bin_edges = get_binned_data(
        reference_data, current_data, feature_type, bins, dropna, eps, float_fmt
    )
    psi_val = _psi(ref_hist["percent"], cur_hist["percent"], eps)
    
    if return_hist:
        return psi_val, ref_hist, cur_hist, bin_edges
    return psi_val

def psi1d_groupby(
    reference_data: pl.Series,
    current_data: pl.DataFrame,
    current_groupby_cols: Union[str, List[str]],
    feature_type: str = 'num',
    bins: Union[int, str] = 30,
    eps: float = 1e-6,
    dropna: bool = False,
    float_fmt: int = 4,
    return_hist: bool = False,
) -> Union[pl.Series, Tuple[pl.Series, pl.DataFrame, pl.DataFrame, pl.Series]]:
    """Calculate PSI for grouped current data."""
    group_cols = [current_groupby_cols] if isinstance(current_groupby_cols, str) else current_groupby_cols
    target_col = reference_data.name
    
    # Get reference histogram
    ref_hist, _, bin_edges, method_used = get_binned_data(
        reference_data, current_data[target_col], feature_type, bins, dropna, eps, float_fmt, True
    )
    
    # Process current data based on binning method
    if method_used == 'num':
        # Bin current data using same edges
        current_binned = current_data.with_columns(
            pl.col(target_col).cut(bin_edges.to_numpy(), labels=bin_edges.to_list()).alias("bin")
        )
        grouped = current_binned.group_by(group_cols).agg(pl.col("bin").value_counts())
        # Pivot to get counts per bin
        display(grouped)
        current_hists = grouped.pivot(values="count", index=group_cols, columns="bin", aggregate_function="first")
    else:
        # Categorical handling
        grouped = current_data.group_by(group_cols + [target_col]).count()
        current_hists = grouped.pivot(values="count", index=group_cols, columns=target_col, aggregate_function="first")
    
    # Calculate percentages and PSI
    current_percents = current_hists.select(group_cols + [pl.all().exclude(group_cols) / pl.sum_horizontal(pl.all().exclude(group_cols))])
    psi_values = current_percents.select(
        pl.struct(pl.all().exclude(group_cols)).map_elements(lambda row: _psi(ref_hist[[target_col, "percent"]].rename({target_col: 'col'}), row))
    )
    psi_series = psi_values.rename({psi_values.columns[-1]: "psi"})
    
    if return_hist:
        return psi_series, ref_hist, current_hists, bin_edges
    return psi_series