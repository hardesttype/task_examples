import pandas as pd
import numpy as np


## Функции Разуваева Никиты
def mean_target_by_score(
    y_score:  pd.Series, 
    y_target: pd.Series or pd.DataFrame,
    bins:     int = 10,
    eps:      float = 1e-6,
):
    from ml_model_monitor.metrics import get_binned_data
    
    ref, cur, bin_edges = get_binned_data(
        y_score, y_score, 
        feature_type='num', bins=bins, 
        dropna=True
    )
    bin_edges[-1] = bin_edges[-1] + eps
    bin_labels = np.searchsorted(bin_edges, y_score, side='right')
    
    index = ref.index.to_series()
    
    mean_target = y_target.groupby(bin_labels)\
    .mean().set_index(index)
    
    total_cnt = y_score.to_frame().groupby(bin_labels)\
    .count().set_index(index)
    
    notna_cnt = y_target.groupby(bin_labels)\
    .count().set_index(index)
    
    ones_cnt = y_target.groupby(bin_labels)\
    .sum().fillna(0).astype(int).set_index(index)
    
    mean_target.columns = pd.MultiIndex.from_product(
        [['mean_target'], mean_target.columns], names=['type', mean_target.columns.name]
    )
    
    total_cnt.columns = pd.MultiIndex.from_product(
        [['total_cnt'], total_cnt.columns], names=['type', total_cnt.columns.name]
    )
    
    notna_cnt.columns = pd.MultiIndex.from_product(
        [['notna_cnt'], notna_cnt.columns], names=['type', notna_cnt.columns.name]
    )
    
    ones_cnt.columns = pd.MultiIndex.from_product(
        [['ones_cnt'], ones_cnt.columns], names=['type', ones_cnt.columns.name]
    )
    
    return pd.concat([mean_target, total_cnt, notna_cnt, ones_cnt], axis=1)\
           .rename_axis(columns=['type', 'variable'])


def target_stats_groupby(
    y_score:  pd.Series, 
    y_target: pd.Series or pd.DataFrame,
    by:       pd.Series or pd.DataFrame,
    score:    str = 'GINI',
):
    from ml_model_monitor.metrics import gini1d
    
    import warnings
    warnings.filterwarnings("ignore")
    
    if type(y_target) == pd.Series:
        y_target = y_target.to_frame()
    
    if type(by) == pd.Series:
        by = by.to_frame()
    
    y_score_name = y_score.name
    y_target_columns = y_target.columns
    y_score = pd.concat([y_score, by], axis=1)
    y_target = pd.concat([y_target, by], axis=1)
    
    agg_score = y_score.groupby(by.columns.to_list()).agg(['mean', 'std', 'count'])
    agg_target = y_target.groupby(by.columns.to_list()).agg(['mean', 'sum', 'std', 'count'])
    
    if not y_target.drop(by.columns, axis=1).isna().all().all() and score == 'GINI':
        gini_target = pd.DataFrame() # columns=y_target.columns
        cache = pd.concat([y_score.drop(by.columns, axis=1), y_target], axis=1)
        notna_columns = ~y_target[y_target_columns].isna().all()
        for target in y_target_columns[notna_columns]:
            cache_ = cache.groupby(by.columns.to_list()).apply(lambda x: gini1d(x[y_score_name], x[target]))
            if type(cache_) == pd.Series:
                cache_ = cache_.to_frame()
            # gini_target = gini_target.append(cache_)
            gini_target = pd.concat([gini_target, cache_], axis=1)
        
        
        gini_target.columns = pd.MultiIndex.from_product(
            [gini_target.columns, [score]], names=['variable', 'type']
        )
        # gini_target = gini_target.rename_axis(index=gini_target.index.names[:-1] + ['variable'])\
        # .reset_index().pivot(index=gini_target.index.names[:-1], columns='variable', values=gini_target.columns)\
        # .swaplevel(0, 1, axis=1).rename_axis(columns=['variable', 'type'])
    elif score == None:
        return pd.concat([agg_target, agg_score], axis=1).swaplevel(0, 1, axis=1)\
        .sort_index(axis=1).rename_axis(columns=['type', 'variable'])
    else:
        gini_target = pd.DataFrame(
            index = agg_target.index,
            columns = pd.MultiIndex.from_product(
                [y_target_columns, [score]],
                names = ['variable', 'type']
            )
        )

    return pd.concat([gini_target, agg_target, agg_score], axis=1).swaplevel(0, 1, axis=1).sort_index(axis=1)
    
    
## Функции Бышкова Олега
def apply_aggfunc_bymodelname(data, modelname_col, agg_colname, aggfunc, month_col=None, seg_col=None):
    """
    Применяет функцию агрегации `aggfunc` и выводит датафрейм следующего вида (если переданы параметры
    `month_col`, `seg_col`): 
    
                                        2024-01	2024-02	2024-03	    2024-04	2024-05	    Seg1	Seg2	Seg3	Seg4	Seg5	agg
    SCORING_MODEL_NAME											
    CARD.PD.V092023	                    8.0	    38.0	64.0	    38.0	NaN	        13.0	14.0	33.0	64.0	24.0	148.0
    INTEGRAL.CARD.PD.MTS.V102023	    136.0	620.0	768.0	    419.0	0.0	        98.0	103.0	277.0	682.0	783.0	1943.0
    INTEGRAL.ONLINE.PD.MTS.BEE.V092021	777.0	127.0	47.0	    29.0	0.0	        110.0	120.0	142.0	399.0	209.0	980.0
    INTEGRAL.ONLINE.PD.MTS.V092021	    450.0	75.0	29.0	    14.0	NaN	        75.0	93.0	82.0	123.0	195.0	568.0
    
    Parameters
    ----------
    data: pd.DataFrame
        датафрейм, обязательно содержащий колонки `aggfunc` и `modelname_col`
    modelname_col: str
        колонка, содержащая имена колонок
    agg_colname: str
        колонка, по которой будет производиться агрегация
    aggfunc: str | Callable
        любая функция или строка с именем встроенной функции, которая принимается pandas.DataFrame.agg методом
    
    Notes:
    ------
    лучше применять в качестве функции агрегации встроенные функции ('sum', 'mean', ...),
    так значительно быстрее идет рассчет 
    
    Examples:
    ---------
    sum_table = apply_aggfunc_bymodelname(
        data, 
        'SCORING_MODEL_NAME', 'IS_MOB02_30P_FLG', 'sum', 'CREATED_MONTH', 'SEGMENT'
    )
    sum_table
    """
    t1, t2 = None, None
    if month_col is not None:
        t1 = data.groupby([modelname_col, month_col])[agg_colname].agg(aggfunc).unstack()
    if seg_col is not None:
        t2 = data.groupby([modelname_col, seg_col])[agg_colname].agg(aggfunc).unstack()
    t_total = data.groupby(modelname_col)[agg_colname].agg(aggfunc)
    t_total.rename('agg', inplace=True)    
    
    stat_df = pd.concat((t1, t2, t_total), axis=1)
    return stat_df

def get_table_by_segment(df: pd.DataFrame, apply_func, target_col_name: str = 'IS_MOB02_30P_FLG'):
    """
    Строит сводную квадратную таблицу по сегментам (SEGMENTS x SEGMENTS field).
    Где (i,j) инедекс соответствует i-му сегменту у одной модели и j-му сегменту у другой.
    Для каждой такой ячейки применяется функция `apply_func`
    
    Params:
    ---------
    df: pd.DataFrame
        данные содержащие колонки ['APPLICATION_NUMBER', 'SEGMENT', `target_col_name`, 'SCORING_MODEL_NAME'].
        для каждой 'APPLICATION_NUMBER' должны соответствовать ровно 2 модели
    
    apply_func: Callable[[row_1, row_2], float]
        функция принимающая 2 строки из `df`.
        важно, чтобы результат колонки был аддитивной функцией
        
    target_col_name: str
        какой таргет мы считаем. Нужно чтобы взять подножество колонок, чтобы
        быстрее происходили вычисления
        
    Notes:
    -------
    Медленно считается, нужно подумать как ускорить. Проблема в цикле и вызове функции в нем
    """
    df = df[['APPLICATION_NUMBER', 'SEGMENT', target_col_name, 'SCORING_MODEL_NAME']]
    df = df.sort_values(['APPLICATION_NUMBER', 'SCORING_MODEL_NAME'])
    df.reset_index(drop=True, inplace=True)
    
    names = np.sort(df['SCORING_MODEL_NAME'].unique())
    segs = np.sort(df['SEGMENT'].unique())
    
    data = { seg: [0] * len(segs) for seg in segs }
    index = [ seg for seg in segs ]
    
    table = pd.DataFrame(data=data, index=index)
    table.rename_axis(names[0], inplace=True, axis=0)
    table.rename_axis(names[1], inplace=True, axis=1)
    
    i = 0
    while i < df.shape[0]:
        row = df.iloc[i]
        col = df.iloc[i+1]
        table[col['SEGMENT']][row['SEGMENT']] += apply_func(row, col)
        i += 2
        
    return table