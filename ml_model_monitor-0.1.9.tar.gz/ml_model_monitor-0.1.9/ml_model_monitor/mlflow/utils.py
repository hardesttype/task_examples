import mlflow

import pandas as pd
import numpy as np

from ml_model_monitor.visuals import *
from ml_model_monitor.statscalc import target_stats_groupby
from ml_model_monitor.metrics import gini1d, prauc1d

import warnings
warnings.filterwarnings("ignore")


def mlflow_evaluation_run(
    data: pd.DataFrame(),
    score: str,
    targets: list,
    time: str = None,
    segment: str = None,
    segments: list = None,
    set_experiment: dict or str = 'auto',
    start_run: dict = dict(),
    log_model: dict = dict(),
):
    
    if type(set_experiment) is str and set_experiment == 'auto':
        with open('../.envrc', 'r') as f:
            MLFLOW_EXPERIMENT_NAME = f.read().split('MLFLOW_EXPERIMENT_NAME=')[1].replace('\n', '')

        mlflow.set_experiment(MLFLOW_EXPERIMENT_NAME)
    else:
        mlflow.set_experiment(**set_experiment)
    
    mlflow.start_run(**start_run)
    
    if segment is None:
        segment = 'EMPTY_SEGMENT'
    
    if segments is None:
        if segment == 'EMPTY_SEGMENT':
            products = ['empty']
        else:
            products = list(data[segment].unique())
    else:
        products = segments
    
    #####  Строим калибровочные кривые, GINI и PRAUC #####
    if segment != 'EMPTY_SEGMENT':
        fig, axes = draw_template(
            shape=(len(products) + 1, 4), multiax_rows=len(products) + 1, 
            title='Score: {0}. Targets: {1}'.format(score, ', '.join(targets))
        )
    else:
        fig, axes = draw_template(
            shape=(1, 4), multiax_rows=1, 
            title='Score: {0}. Targets: {1}'.format(score, ', '.join(targets)),
            figsize = (20, 5)
        )

    product = 'all'.upper()

    _data = data.dropna(
        subset=[score]
    ).copy().assign(EMPTY_SEGMENT = 'empty')

    plot_score_kde(
        _data[score], 
        _data[targets[-1]], 
        ax=axes[0],
        title=f'Score distribution: {product}',
    )

    plot_calibration_curve(
        _data[score], 
        _data[targets], 
        ax=axes[1],
        title=f'Calibration curve: {product}',
    )

    scores_gini, (fpr, tpr, roc_auc) = gini1d(
        _data[score], 
        _data[targets], 
        return_roc_curve=True
    )

    plot_roc_curve(fpr, tpr, scores_gini, ax=axes[2], model_name=product)
    
    mlflow.log_metrics({'GINI_' + k + '_' + product.upper(): v for k, v in scores_gini.to_dict().items()})

    scores_prauc, (precision, recall, pr_auc) = prauc1d(
        _data[score], 
        _data[targets], 
        return_pr_curve=True
    )
    plot_pr_curve(precision, recall, scores_prauc, ax=axes[3], model_name=product)
    
    mlflow.log_metrics({'PRAUC_' + k + '_' + product.upper(): v for k, v in scores_prauc.to_dict().items()})
    
    if segment != 'EMPTY_SEGMENT':
        for i, product in enumerate(products, start=1):
            _data = data[data[segment] == product].dropna(
                subset=[score]
            ).copy()

            plot_score_kde(
                _data[score], 
                _data[targets[-1]], 
                ax=axes[4*i],
                title=f'Score distribution: {product.upper()}',
            )

            plot_calibration_curve(
                _data[score], 
                _data[targets], 
                ax=axes[4*i + 1],
                title=f'Calibration curve: {product.upper()}',
            )

            scores_gini, (fpr, tpr, roc_auc) = gini1d(
                _data[score], 
                _data[targets], 
                return_roc_curve=True
            )

            plot_roc_curve(fpr, tpr, scores_gini, ax=axes[4*i + 2], model_name=product.upper())
            
            mlflow.log_metrics({'GINI_' + k + '_' + product.upper(): v for k, v in scores_gini.to_dict().items()})

            scores_prauc, (precision, recall, pr_auc) = prauc1d(
                _data[score], 
                _data[targets], 
                return_pr_curve=True
            )
            plot_pr_curve(precision, recall, scores_prauc, ax=axes[4*i + 3], model_name=product.upper())

            mlflow.log_metrics({'PRAUC_' + k + '_' + product.upper(): v for k, v in scores_prauc.to_dict().items()})
        
    mlflow.log_figure(fig, f"OVERALL_{score}.png")
    
    plt.show()
    
    if time is not None:
        ##### Рассчитываем GINI по месяцам и продуктам #####
        all_target_stats = target_stats_groupby(
            data[score], data[targets],
            data[time]
        )

        all_target_stats = all_target_stats.set_index(pd.MultiIndex.from_product(
            [all_target_stats.index, ['all']], 
            names=[all_target_stats.index.name, segment]
        ))

        prod_target_stats = target_stats_groupby(
            data[score], data[targets],
            data.assign(EMPTY_SEGMENT = 'empty')[[time, segment]]
        )

        target_stats =\
        pd.concat([all_target_stats, prod_target_stats]).sort_index()
        
        ##### Мониториг GINI #####
            
        # Шаблон для отрисовки 5 графиков
        fig, axes = draw_template(
            shape=(5, 2), 
            multiax_rows=0, 
            title=f'GINI: {score}', 
            whspace=(0.25, 0.45)
        )

        # Отрисовка графиков
        for ax, product in zip(axes, ['all'] + products):
            _data = target_stats.xs(product, level=segment)['GINI']
            plot_lines_and_bins(
                _data[_data > 0], 
                target_stats.xs(product, level=segment)\
                ['count'][targets[0]], 
                ax = ax, 
                title = f'GINI for {product}',
                legend_loc = 'upper right',
                ylabels = ['count TARGET', 'GINI'],
            )
        
        mlflow.log_figure(fig, f"GINI_{score}.png")
        
        plt.show()
    
    if log_model is not None and len(log_model) > 0:
        mlflow.pyfunc.log_model(**log_model)
    
    mlflow.end_run()
