import mlflow
import json

import pandas as pd
import numpy as np

from decimal import Decimal


class BaseMLFlowIntegralModel(mlflow.pyfunc.PythonModel):
    
    def predict_one(self, x: pd.Series) -> float:
        raise NotImplementedError('Define this function to improve prediction speed!')
        
    def _load_weights(self, weights) -> None:
        raise NotImplementedError('Define this function to store weights within the class!')
    
    def _load_segments(self, segments) -> None:
        raise NotImplementedError('Define this function to store segments within the class!')
    
    def __init__(
        self, 
        model_name: str = None,
        weights: str or pd.DataFrame = None,
        segments: list = None,
        csv_read_params: dict = dict(
            index_col = 0,
            sep = ',',
        ),
        excel_read_params: dict = dict(
            index_col = 0,
        ),
        pickle_read_params: dict = dict(),
        parquet_read_params: dict = dict(),
    ):
        
        self.load_weights(weights)
        self._validate_coefs()
        
        self.load_segments(segments)

        self.model_name = model_name
        
    def load_segments(self, segments: list) -> None:
        try:
            self._load_segments(segments)
        except:
            if segments is not None:
                self.segments = segments
                self.segment2features = {
                    segment: self._W.loc[segment][self._W.loc[segment] != 0].index.to_list()
                    for segment in self.segments
                }
            else:
                self.segments = self._W.index.to_list()
                self.segment2features = {
                    segment: self._W.loc[segment][self._W.loc[segment] != 0].index.to_list()
                    for segment in self.segments
                }
    
    def load_weights(self, weights: str or pd.DataFrame) -> None:
        if type(weights) == str:
            if weights.split('.')[-1] == 'csv':
                self.W = pd.read_csv(weights, **csv_read_params).replace({-1: np.nan})
            elif weights.split('.')[-1] == 'xlsx':
                self.W = pd.read_excel(weights, **excel_read_params).replace({-1: np.nan})
            elif weights.split('.')[-1] in ['pickle', 'pkl']:
                self.W = pd.read_pickle(weights, **pickle_read_params).replace({-1: np.nan})
            elif weights.split('.')[-1] in ['parquet', 'pq']:
                self.W = pd.read_parquet(weights, **parquet_read_params).replace({-1: np.nan})
            else:
                raise ValueError('Choose the correct file!')
        elif type(weights) == pd.DataFrame:
            self.W = weights.replace({-1: np.nan})
        else:
            try:
                self._load_weights(weights)
            except:
                raise ValueError('Load weights from file/pd.DataFrame or define _load_weights() function!')
        
        self._W = self.W.fillna(0).drop(columns = 'INTERCEPT')
        self._b = self.W.loc[:, 'INTERCEPT']
        
    def _validate_coefs(self):
        if (self._W < 0).any().any():
            raise ValueError('Model has negative coefficients!')
    
    @staticmethod
    def _inverse_sigmoid(x: pd.Series or pd.DataFrame) -> pd.Series or pd.DataFrame:
        return np.log(x / (1 - x)) # np.log(-1 + 1 / (1 - x))
    
    @staticmethod
    def _sigmoid(x: pd.Series or pd.DataFrame) -> pd.Series or pd.DataFrame:
        return 1 / (1 + np.exp(-x))
    
    @staticmethod
    def _add_const(x: pd.Series or pd.DataFrame) -> pd.Series:
        if x.ndim == 1:
            x.at['INTERCEPT'] = 1
            return x
        elif x.ndim == 2:
            return x.assign(INTERCEPT = 1)
        else:
            raise NotImplementedError('Not Implemented!')
    
    @staticmethod
    def load_jsons(json_input: str) -> pd.DataFrame:
        X = pd.json_normalize(json.loads(json_input)).astype(float)
        return X
    
    def load_json(self, json_input: str) -> pd.Series:
        x = self.load_jsons(json_input).iloc[0]
        return x
    
    def to_json(self, score_value: float, feature_values: pd.Series) -> str:
        if self.model_name is None:
            raise ValueError('Define model_name!')
        
        model_name = self.model_name
        score_value = str(format(Decimal(score_value), '.8f'))
        feature_values = feature_values.to_json(orient="index")
        
        return "~".join([model_name, score_value, feature_values]).replace('nan','NULL')
    
    def prepare_data(
        self, 
        x: pd.Series or pd.DataFrame
    ) -> pd.Series or pd.DataFrame:
        return self._inverse_sigmoid(x).fillna(0)
    
    def predict_segment(self, x: pd.Series, segment: str) -> float:
        return self._sigmoid(self.prepare_data(x) @ self._W.loc[segment] + self._b.at[segment])
    
    def _predict_one(self, x: pd.Series) -> float:
        
        for segment, features in self.segment2features.items():
            if x[features].ge(0).all() and x[features].le(1).all():
                return self.predict_segment(x, segment)
        
        return -1
    
    def predict_many(self, X: pd.DataFrame) -> pd.Series:
        try:
            # Call custom function
            preds = X.apply(self.predict_one, axis=1)
        except:
            # Call automatic function. 3 times slower
            preds = X.apply(self._predict_one, axis=1)
            
        return preds
    
    def predict_json(self, json_input: str) -> str:
        x = self.load_json(json_input)
        
        try:
            pred = self.predict_one(x)
        except:
            pred = self._predict_one(x)
            
        if pred == -1:
            return -1
        else:
            return self.to_json(pred, x.fillna(-1))
    
    def predict_jsons(self, json_input: str) -> str:
        X = self.load_jsons(json_input)
        pred = self.predict_many(X)
        return pred
        
    def predict(self, context, model_input):
        return self.predict_json(model_input)
