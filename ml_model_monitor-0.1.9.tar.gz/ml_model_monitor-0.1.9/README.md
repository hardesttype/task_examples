# Мониторинг моделей

- В папке `online` лежит процедурный пакет технического мониторинга моделей в ЕХД с логгированием

- Гайд по созданию Python пакетов и их публикации в GitLab: [GitLabPackageRegistryGuide.md](https://gitlab.mtsbank.ru/ds-risk/monitoring/-/blob/d9f65342ed6782596c8dc878105874b5cad1af40/GitLabPackageRegistryGuide.md)

- Пример ноутбука с заполнением рэнжей для мониторинга PSI для интегральной модели INTEGRAL.ONLINE.PD.MTS.BEE.V012023: [insert_score_feature_range.ipynb](https://gitlab.mtsbank.ru/ds-risk/monitoring/-/blob/e9d720ff25a28198d036219f6ae6d19c2a908a55/%D0%9D%D0%BE%D1%83%D1%82%D0%B1%D1%83%D0%BA%D0%B8/insert_score_feature_range.ipynb)

## Пакет `ml_model_monitor`

- Установка:
```bash
pip install ml-model-monitor --extra-index-url https://gitlab+deploy-token-580:tdXRs6ZeKy5jdoNsj8-d@gitlab.mtsbank.ru/api/v4/projects/3303/packages/pypi/simple
```

При необходимости прописать прокси:
```bash
export no_proxy=mtsbank.ru
```
или
```bash
export https_proxy="http://<username>:<password>@11.222.64.63:1010"
```

- Месячный мониторинг моделей с помощью пакета: [MonthlyReport.ipynb](https://gitlab.mtsbank.ru/ds-risk/monitoring/-/blob/0cbba491e4463459fb2bd515c3afda7945141a21/MonthlyReport.ipynb)

- Структура: 
```
monitoring/
    |ml_model_monitor/
        |__init__.py
        |metrics.py
        |reports.py
        |statscalc.py
        |utils.py
        |visuals.py
        |setup.py
```

## TO DO

- PSI за последний месяц по дням против предыдущего
- Сегменты
- Исправить расчет риска. См. [DS-382](https://jira.mtsbank.ru/browse/DS-382)
