import setuptools

setuptools.setup(
    name="ml_model_monitor",
    version="0.1.9",
    author="Nikita Razuvaev",
    author_email="nrazuvaev@mtsbank.ru",
    description="Tools for monitoring the quality of ML models",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
    install_requires=[
       'pandas==1.5.3',
       'polars-lts-cpu==1.10.0',
       'cx_Oracle==8.3.0',
       'psycopg2-binary==2.9.10',
       'seaborn==0.13.2',
       'tqdm',
       'scikit-learn==1.5.1',
       'pyarrow==16.1.0',
       'openpyxl==3.1.5',
    ]
)
