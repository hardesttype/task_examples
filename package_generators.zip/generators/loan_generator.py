import polars as pl

try:
    from feature_aggregator import FeatureAggregator
    from base_generator     import BaseGenerator
    from preprocess         import Discounter
except Exception as err:
    from generators.feature_aggregator import FeatureAggregator
    from generators.base_generator     import BaseGenerator
    from generators.preprocess         import Discounter


class LoanGenerator(BaseGenerator):
    """Класс для генерации и предобработки кредитных данных.

    Обрабатывает сырые данные: переименование колонок, преобразование типов,
    создание новых признаков (например, из платежной строки), фильтрация и агрегация.

    Attributes:
        id_column (str): Колонка-идентификатор (по умолчанию "APPLICATION_NUMBER").
        date_column (str): Колонка с датой заявки.
        depth_filters (int): Макс. глубина комбинаций фильтров. Для оптимальности используйте значение 3. (по умолчанию 10)
        n_jobs (int): Количество параллельных задач. Для оптимальной скорости используйте значение 4. (по умолчанию 1)
        verbose (bool): Флаг вывода прогресса.
        mask (Tuple[bool]): Маска для фильтрации признаков.
        cast_dtypes (bool): Флаг приведения типов в предобработке (по умолчанию True)
        config (Dict): Готовый конфиг
        open_date_column (str): Колонка с датой открытия кредита.
    """
    numeric_columns = [
        "CREDIT_LIMIT",
        "OUTSTANDING",
        "EST_NEXT_PMT",
        "DELQ_BALANCE",
        "MAX_DELQ_BALANCE",
        "CURR_BALANCE_AMT",
        "EST_CURR_BALANCE_AMT",

        'CREDIT_LIMIT_DCW',
        'OUTSTANDING_DCW',
        'EST_NEXT_PMT_DCW',
        'CURR_BALANCE_AMT_DCW',
        'EST_CURR_BALANCE_AMT_DCW',
        'DELQ_BALANCE_DCW',
        'MAX_DELQ_BALANCE_DCW',

        # 'NEXT_PMT',           # Нестабильна после 2022-10
        # "MAX_PAYMENT",        # Нестабильна до 2022-10
        # 'CURRENT_DELQ_MONTH', # Берем current_delq
        # 'CURR_DELQ_AMT',      # Убрал
        # "CUR_TO_BASE_LIMIT",  # Заполняется только значением 1, начиная с 2022-10

        "CURRENT_DELQ",
        "CREDIT_COST_RATE",

        "TTL_DELQ_5",
        "TTL_DELQ_5_29",
        "TTL_DELQ_7",
        "TTL_DELQ_8_29",
        "TTL_DELQ_30_59",
        "TTL_DELQ_60_89",
        # "TTL_DELQ_30",       # = PMT_STRING_84M_CNT_1_29
        # "TTL_DELQ_90_PLUS",  # = PMT_STRING_84M_CNT_90_PLUS
        
        'DIFF_APPLICATION_DAY_OPEN_DATE',
        'DIFF_APPLICATION_DAY_FACT_CLOSE_DATE',
        'DIFF_APPLICATION_DAY_FINAL_PMT_DATE',
        # 'DIFF_APPLICATION_DAY_LAST_PAYMENT_DATE',
        # 'DIFF_APPLICATION_DAY_INF_CONFIRM_DATE',
        # 'DIFF_APPLICATION_DAY_PMT_STRING_START',
        # 'DIFF_CLOSEDDT_OPENEDDT',
        'DIFF_FACT_CLOSE_DATE_OPEN_DATE',
        'DIFF_FINAL_PMT_DATE_OPEN_DATE',
        # 'DIFF_LAST_PAYMENT_DATE_OPEN_DATE',
        # 'DIFF_INF_CONFIRM_DATE_OPEN_DATE',
        # 'DIFF_PMT_STRING_START_OPEN_DATE',

        # Фичи отношений
        ## С датами
        'FACT_CLOSE_DATE_TO_FINAL_PMT_DATE',
        'APPLICATION_DAY_TO_FINAL_PMT_DATE',
        # С суммами
        'UTILIZATION',
        'EST_NEXT_PMT_TO_OUTSTANDING',
        'EST_CURR_BALANCE_AMT_TO_OUTSTANDING',
        'CURR_BALANCE_AMT_TO_OUTSTANDING',
        'DELQ_BALANCE_TO_OUTSTANDING',
        'MAX_DELQ_BALANCE_TO_OUTSTANDING',
        'EST_NEXT_PMT_TO_CREDIT_LIMIT',
        'EST_CURR_BALANCE_AMT_TO_CREDIT_LIMIT',
        'CURR_BALANCE_AMT_TO_CREDIT_LIMIT',
        'DELQ_BALANCE_TO_CREDIT_LIMIT',
        'MAX_DELQ_BALANCE_TO_CREDIT_LIMIT',
        'EST_CURR_BALANCE_AMT_TO_EST_NEXT_PMT',
        'CURR_BALANCE_AMT_TO_EST_NEXT_PMT',
        'DELQ_BALANCE_TO_EST_NEXT_PMT',
        'MAX_DELQ_BALANCE_TO_EST_NEXT_PMT',

        # Фичи платежной строки
        'PMT_STRING_3M_CNT_ON_TIME',
        'PMT_STRING_3M_CNT_1_29',
        'PMT_STRING_3M_CNT_30_PLUS',
        # 'PMT_STRING_3M_CNT_60_PLUS',
        # 'PMT_STRING_3M_CNT_90_PLUS',
        'PMT_STRING_3M_CNT_REFIN',
        # 'PMT_STRING_3M_CNT_DELQ', # новая
        'PMT_STRING_6M_CNT_ON_TIME',
        'PMT_STRING_6M_CNT_1_29',
        'PMT_STRING_6M_CNT_30_PLUS',
        # 'PMT_STRING_6M_CNT_60_PLUS',
        # 'PMT_STRING_6M_CNT_90_PLUS',
        'PMT_STRING_6M_CNT_REFIN',
        # 'PMT_STRING_6M_CNT_DELQ', # новая
        'PMT_STRING_12M_CNT_ON_TIME',
        'PMT_STRING_12M_CNT_1_29',
        'PMT_STRING_12M_CNT_30_PLUS',
        # 'PMT_STRING_12M_CNT_60_PLUS',
        # 'PMT_STRING_12M_CNT_90_PLUS',
        'PMT_STRING_12M_CNT_REFIN',
        # 'PMT_STRING_12M_CNT_DELQ', # новая
        # 'PMT_STRING_24M_CNT_ON_TIME',
        # 'PMT_STRING_24M_CNT_1_29',
        # 'PMT_STRING_24M_CNT_30_PLUS',
        # 'PMT_STRING_24M_CNT_60_PLUS',
        # 'PMT_STRING_24M_CNT_90_PLUS',
        # 'PMT_STRING_24M_CNT_REFIN',
        'PMT_STRING_84M_CNT_ON_TIME',
        'PMT_STRING_84M_CNT_1_29',
        'PMT_STRING_84M_CNT_30_PLUS',
        # 'PMT_STRING_84M_CNT_60_PLUS',
        # 'PMT_STRING_84M_CNT_90_PLUS',
        'PMT_STRING_84M_CNT_REFIN',
        # 'PMT_STRING_84M_CNT_DELQ', # новая

        # reverse
        'PMT_STRING_REV_3M_CNT_ON_TIME',
        'PMT_STRING_REV_3M_CNT_REFIN',
        'PMT_STRING_REV_3M_CNT_1_29',
        'PMT_STRING_REV_3M_CNT_30_PLUS',
        
        'PMT_STRING_REV_6M_CNT_ON_TIME',
        'PMT_STRING_REV_6M_CNT_REFIN',
        'PMT_STRING_REV_6M_CNT_1_29',
        'PMT_STRING_REV_6M_CNT_30_PLUS',
        
        'PMT_STRING_REV_12M_CNT_ON_TIME',
        'PMT_STRING_REV_12M_CNT_REFIN',
        'PMT_STRING_REV_12M_CNT_1_29',
        'PMT_STRING_REV_12M_CNT_30_PLUS',
        
        # новая
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_6M_CNT_ON_TIME",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_12M_CNT_ON_TIME",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_84M_CNT_ON_TIME",
        
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_6M_CNT_30_PLUS",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_12M_CNT_30_PLUS",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_84M_CNT_30_PLUS",

        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_6M_CNT_1_29",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_12M_CNT_1_29",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_84M_CNT_1_29",
        
        # reverse
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_REV_6M_CNT_ON_TIME",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_REV_12M_CNT_ON_TIME",
        
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_REV_6M_CNT_30_PLUS",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_REV_12M_CNT_30_PLUS",

        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_REV_6M_CNT_1_29",
        "MUL_EST_NEXT_PMT_DCW_PMT_STRING_REV_12M_CNT_1_29",
    ]

    category_num_columns = [
        "IS_OWN",
        "LOAN_PRIORITY",
        "RELATIONSHIP",
        "COLLATERAL_CODE",
        "PMT_FREQ",
        "BUSINESS_CATEGORY",
        'LOAN_TYPE',
    ]
    category_str_columns = [
        "LOAN_STATUS_CODE",
        "LOAN_TYPE_MAP",
        # "CURRENCY_MAP",
    ]
    date_columns = [
        "OPEN_DATE",
        "FACT_CLOSE_DATE",
        "FINAL_PMT_DATE",
        "LAST_PAYMENT_DATE",
        "INF_CONFIRM_DATE",
        "PMT_STRING_START",
    ]
    rename_mapping = {
        "REQUESTID":            "REQUESTID",
        "STAGEID":              "STAGEID",
        "DT_CREATED":           "APPLICATION_DAY",
        "BANKID":               "IS_OWN",
        "OPENEDDT":             "OPEN_DATE",
        "FACT_CLOSE_DATE":      "FACT_CLOSE_DATE",
        "CLOSEDDT":             "FINAL_PMT_DATE",
        "LASTPAYMENTDATE":      "LAST_PAYMENT_DATE",
        "CREDITSUM":            "CREDIT_LIMIT",
        "NEXTLOANPAYMENT":      "NEXT_PMT",
        "MONTHLYAMT":           "EST_NEXT_PMT",
        "LOANAMOUNT":           "OUTSTANDING",
        "MAXLOANPAYMENT":       "MAX_PAYMENT",
        "DELINQAGINGAMT":       "DELQ_BALANCE",
        "TOTALPMTAMT":          "CURR_BALANCE_AMT",
        "DATEINFORMATION":      "INF_CONFIRM_DATE",
        "LOANSTATUSCODE":       "LOAN_STATUS_CODE",
        "LOAN_STATUS":          "LOAN_STATUS",
        "MAXOVERDEBTMAXVALUE":  "MAX_DELQ_BALANCE",
        "DUEBACKPAYM":          "CURRENT_DELQ",
        "PAYMSTRINGSTART":      "PMT_STRING_START",
        "NBCHPAYMSTRING":       "PMT_STRING_84M",
        "RELATIONSHIP":         "RELATIONSHIP",
        "COLLATERAL_CODE":      "COLLATERAL_CODE",
        "CUR_TO_BASE_LIMIT":    "CUR_TO_BASE_LIMIT",
        "EST_CURR_BALANCE_AMT": "EST_CURR_BALANCE_AMT",
        "PMT_FREQ":             "PMT_FREQ",
        "TTL_DELQ_5":           "TTL_DELQ_5",
        "TTL_DELQ_5_29":        "TTL_DELQ_5_29",
        "PASTDUEPMTCOUNT1":     "TTL_DELQ_30",
        "TTL_DELQ_7":           "TTL_DELQ_7",
        "TTL_DELQ_8_29":        "TTL_DELQ_8_29",
        "PASTDUEPMTCOUNT30":    "TTL_DELQ_30_59",
        "PASTDUEPMTCOUNT60":    "TTL_DELQ_60_89",
        "PASTDUEPMTCOUNT90":    "TTL_DELQ_90_PLUS",
        "CREDIT_COST_RATE":     "CREDIT_COST_RATE",
        "BUSINESS_CATEGORY":    "BUSINESS_CATEGORY",
        "LOAN_TYPE":            "LOAN_TYPE",
        "LOANAMTCUR":           "CURRENCY",
        "UUID":                 "UUID",
        # Заполнена по ~ 1 тыс. кредитов из 18 млн.
        # "DISPUTE_FLAG":         "DISPUTE_FLAG",
        # Не заполняется с 2022-11
        # "INTRATE":              "INTEREST_RATE",
        # Используем маппинг в "LOAN_STATUS_CODE"
        # "LOAN_PRIORITY":        "LOAN_PRIORITY",
        # Стратегию расчета не используем 
        # "STRATEGY_ID":          "STRATEGY_ID",
        # Везде = 0
        # "CRED_PDN_FLG":         "CRED_PDN_FLG",
        # Идентификатор счета в МТС-Банке - для фичей не нужен
        # "ACCOUNT":              "ACCOUNT",
        # Год закрытия можно выделить из "FACT_CLOSE_DATE"
        # "FACT_CLOSE_YEAR":      "FACT_CLOSE_YEAR",
        # Везде = 0
        # "FILTER_STR":           "FILTER_STR",
    }
                
    allowed_filters = {
        "":              FeatureAggregator.make_expr_config("REQUESTID", "is_not_null", ""), # пустой фильтр
        'WORK':          FeatureAggregator.make_expr_config("LOAN_STATUS_CODE", "eq", "", 'WORK'),
        'CLOSE':         FeatureAggregator.make_expr_config("LOAN_STATUS_CODE", "eq", "", 'CLOSE'),
        'SOLD':          FeatureAggregator.make_expr_config("LOAN_STATUS_CODE", "eq", "", 'SOLD'),
        'POTREB':        FeatureAggregator.make_expr_config("LOAN_TYPE_MAP", "eq", "", 'POTREB'),
        'CC':            FeatureAggregator.make_expr_config("LOAN_TYPE_MAP", "eq", "", 'CC'),
        'MICRO':         FeatureAggregator.make_expr_config("LOAN_TYPE_MAP", "eq", "", 'MICRO'),
        'MORTGAGE':      FeatureAggregator.make_expr_config("LOAN_TYPE_MAP", "eq", "", 'MORTGAGE'),
        'AUTO':          FeatureAggregator.make_expr_config("LOAN_TYPE_MAP", "eq", "", 'AUTO'),
        'OTHER':         FeatureAggregator.make_expr_config("LOAN_TYPE_MAP", "eq", "", 'OTHER'),
        
        # 'MTSB':          FeatureAggregator.make_expr_config("IS_OWN", "eq", "", 1),
        # 'notMTSB':       FeatureAggregator.make_expr_config("IS_OWN", "ne", "", 1),
        
        'COLLATERAL':    FeatureAggregator.make_expr_config("COLLATERAL_CODE", "is_not_null", ""),
        'notCOLLATERAL': FeatureAggregator.make_expr_config("COLLATERAL_CODE", "is_null", ""),
        
        # 'OPEN01M':       FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_OPEN_DATE", "le", "", 1),
        # 'OPEN03M':       FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_OPEN_DATE", "le", "", 3),
        # 'OPEN06M':       FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_OPEN_DATE", "le", "", 6),
        # 'OPEN12M':       FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_OPEN_DATE", "le", "", 12),
        # 'OPEN24M':       FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_OPEN_DATE", "le", "", 24),
        # 'OPEN36M':       FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_OPEN_DATE", "le", "", 36),

        # Cтарые данные не использовать
        'CONFIRM01M':    FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_INF_CONFIRM_DATE", "le", "",  1),
        'CONFIRM06M':    FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_INF_CONFIRM_DATE", "le", "",  6),
        'CONFIRM12M':    FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_INF_CONFIRM_DATE", "le", "", 12),
        'CONFIRM24M':    FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_INF_CONFIRM_DATE", "le", "", 24),

        # Учитывать кредиты, которые закроются только после 6 / 12 месяцев с даты заявки 
        'CLOSEAFTER06M': FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_FINAL_PMT_DATE", "le", "",  -6),
        'CLOSEAFTER12M': FeatureAggregator.make_expr_config("DIFF_APPLICATION_DAY_FINAL_PMT_DATE", "le", "", -12),

        # Посчитать суммы по тем кредитам, где была просрочка
        # 'CNT1DELQ12M':   FeatureAggregator.make_expr_config("PMT_STRING_12M_CNT_DELQ", "ge", "", 1),
        # 'CNT3DELQ12M':   FeatureAggregator.make_expr_config("PMT_STRING_12M_CNT_DELQ", "ge", "", 3),
        'CNT1DELQ84M':   FeatureAggregator.make_expr_config("PMT_STRING_84M_CNT_DELQ", "ge", "", 1),
        'CNT3DELQ84M':   FeatureAggregator.make_expr_config("PMT_STRING_84M_CNT_DELQ", "ge", "", 3),
        'CNT6DELQ84M':   FeatureAggregator.make_expr_config("PMT_STRING_84M_CNT_DELQ", "ge", "", 6),
                
        # 'FREQ30P':       FeatureAggregator.make_expr_config("PMT_FREQ", "is_not_in", "bki_gen", [1, 2, 3, 14, 15]),
    }
    allowed_num_aggregations = (
        lambda column: FeatureAggregator.make_expr_config(column, "last_not_null", "bki_gen") | {"function_alias": "last"},
        lambda column: FeatureAggregator.make_expr_config(column, "count", "")                | {"function_alias": "count"},
        lambda column: FeatureAggregator.make_expr_config(column, "sum", "")                  | {"function_alias": "sum"},
        lambda column: FeatureAggregator.make_expr_config(column, "mean", "")                 | {"function_alias": "mean"},
        # lambda column: FeatureAggregator.make_expr_config(column, "max", "")                  | {"function_alias": "max"},
        # lambda column: FeatureAggregator.make_expr_config(column, "min", "")                  | {"function_alias": "min"},
        lambda column: FeatureAggregator.make_expr_config(column, "quantile", "", .10)        | {"function_alias": "q10"},
        lambda column: FeatureAggregator.make_expr_config(column, "median", "")               | {"function_alias": "median"},
        lambda column: FeatureAggregator.make_expr_config(column, "quantile", "", .90)        | {"function_alias": "q90"},
        # lambda column: FeatureAggregator.make_expr_config(column, "std", "")           | {"function_alias": "std"},
    )
    sort_cols = ['OPEN_DATE', 'CREDIT_LIMIT', 'CREDIT_COST_RATE', 'IS_OWN', 'FACT_CLOSE_DATE', 'FINAL_PMT_DATE']

    def __init__(
        self,
        id_column:        str  = "APPLICATION_NUMBER",
        date_column:      str  = "APPLICATION_DAY",
        depth_filters:    int  = 10,
        n_jobs:           int  = 1,
        verbose:          bool = False,
        cast_dtypes:      bool = True,
        config:           dict = None,
        open_date_column: str  = "OPEN_DATE",
    ):
        """Инициализация LoanGenerator."""

        # Исключить генерацию недисконтированных фичей
        black_list = [
            "CREDIT_LIMIT", "OUTSTANDING", "EST_NEXT_PMT",
            "DELQ_BALANCE", "MAX_DELQ_BALANCE", "CURR_BALANCE_AMT",
            "EST_CURR_BALANCE_AMT",
        ]
        numeric_columns = [col for col in self.numeric_columns if col not in black_list]
        
        super().__init__(
            id_column,
            date_column,
            depth_filters,
            self.allowed_filters,
            numeric_columns, # self.numeric_columns,
            self.allowed_num_aggregations,
            verbose,
            cast_dtypes,
            n_jobs,
            config,
        )

        self.open_date_column = open_date_column

        discount_rates = {
            'CREDIT_LIMIT':         0.001816,
            'OUTSTANDING':          0.001985,
            'EST_NEXT_PMT':         0.002127,
            'CURR_BALANCE_AMT':     0.000576,
            'EST_CURR_BALANCE_AMT': 0.001213,
            'DELQ_BALANCE':         0.000906,
            'MAX_DELQ_BALANCE':     0.003377,
        }
        self.discounter = Discounter(
            id_column, 
            date_column, 
            list(discount_rates.keys()), 
            'weekly',
            rolling_period='12i',
            suffix='_DCW',
            method='beta',
        ).set_rates(discount_rates)

    def preprocess(self, df: pl.DataFrame) -> pl.DataFrame:
        """Предобработка данных: переименование, преобразование типов, создание признаков.

        Args:
            df (pl.DataFrame): Сырые данные.

        Returns:
            pl.DataFrame: Обработанные данные.
        """
        # Переименование столбцов
        df = df.unique().rename(self.rename_mapping)

        if self.cast_dtypes:
            # Преобразование типов
            df = df.with_columns([ 
                # Преобразование типов для дат
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                    .str.strptime(pl.Datetime).dt.truncate("1d")
                for col in [self.date_column] + self.date_columns
                if col in df.columns
            ] + [ 
                # Преобразование типов для численных и категориально-численных признаков
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                    .cast(pl.Float32)
                for col in self.numeric_columns + self.category_num_columns
                if col in df.columns
            ] + [ 
                # Преобразование типов для категориальных признаков
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                for col in self.category_str_columns
                if col in df.columns
            ])

        # Фильтрация
        # df = df.filter(
        #     # Выкидываем не наши кредиты
        #     pl.col('IS_OWN').ne(1)
        # )
        
        # Фильтрация
        df = df.filter(~(
            # Выкидываем кредиты с очень старой датой открытия или без нее
            pl.col('OPEN_DATE').le(pl.date(2000, 1, 1)) |
            pl.col('OPEN_DATE').is_null() |
            pl.col('OPEN_DATE').gt(pl.col('APPLICATION_DAY')) |
            # Выкидываем кредиты с пустым лимитом
            pl.col('CREDIT_LIMIT').is_null() |
            # Выкидываем кредиты не в рублях
            pl.col('CURRENCY').ne('RUB')
        ))

        # Исправления в данных
        df = df.with_columns([
            # Плановая дата закрытия кредита не может быть до даты открытия
            pl.col('FINAL_PMT_DATE')
                .clip(pl.col('OPEN_DATE'), None)
                .alias('FINAL_PMT_DATE'),
            # Фактическая дата закрытия кредита не может быть до даты открытия
            # и не может быть после даты заявки (в будущем)
            pl.when(pl.col('FACT_CLOSE_DATE').ge(pl.date(9000, 1, 1)))
                .then(None)
                .otherwise(pl.col('FACT_CLOSE_DATE'))
                .clip(pl.col('OPEN_DATE'), pl.col('APPLICATION_DAY'))
                .alias('FACT_CLOSE_DATE'),
            # Подтверждение информации по счету не может быть больше даты заявки
            # и не может быть до даты открытия
            pl.when(pl.col('INF_CONFIRM_DATE').ge(pl.date(9000, 1, 1)))
                .then(None)
                .otherwise(pl.col('INF_CONFIRM_DATE'))
                .clip(pl.col('OPEN_DATE'), pl.col('APPLICATION_DAY'))
                .alias('INF_CONFIRM_DATE'),
            # После 2022-11 появились NaN
            pl.col('CURR_BALANCE_AMT')
                .fill_nan(0).fill_null(0)
                .alias('CURR_BALANCE_AMT'),
            # После 2022-11 появились NaN, заполняем значением 3 - ежемесячно
            pl.col('PMT_FREQ')
                .fill_nan(3).fill_null(3)
                .alias('PMT_FREQ'),
            # После 2022-11 пропали NaN
            pl.col('TTL_DELQ_7')
                .fill_nan(0).fill_null(0)
                .alias('TTL_DELQ_7'),
            # После 2022-11 пропали NaN
            pl.col('TTL_DELQ_8_29')
                .fill_nan(0).fill_null(0)
                .alias('TTL_DELQ_8_29'),
            # После 2022-11 пропали NaN. Нестабильна до 2022-10
            # pl.col('MAX_PAYMENT')
            #     .fill_nan(0).fill_null(0)
            #     .alias('MAX_PAYMENT'),
            # Заполняем всплески пропуском значением 0
            pl.col('DELQ_BALANCE')
                .fill_nan(0).fill_null(0)
                .alias('DELQ_BALANCE'),
            # Заполняем всплески пропуском значением 0
            pl.col('MAX_DELQ_BALANCE')
                .fill_nan(0).fill_null(0)
                .alias('MAX_DELQ_BALANCE'),
            # Заполняем всплески пропуском значением 0
            pl.col('OUTSTANDING')
                .fill_nan(0).fill_null(0)
                .alias('OUTSTANDING'),
        ])

        df = df.with_columns([
            # Если дата закрытия заполнена, то кредит не может быть открытым
            pl.when(pl.col('FACT_CLOSE_DATE').is_not_null() & pl.col('LOAN_STATUS_CODE').eq("WORK"))
                .then(pl.lit('CLOSE'))
                .otherwise(pl.col("LOAN_STATUS_CODE"))
                .alias("LOAN_STATUS_CODE"),
            # Если дата планового закрытия заполнена бесконечностью, то это кредитная карта
            pl.when(pl.col('FINAL_PMT_DATE').ge(pl.date(9000, 1, 1)) & pl.col('LOAN_TYPE').is_in([9, 99]))
                .then(7)
                .otherwise(pl.col("LOAN_TYPE"))
                .alias("LOAN_TYPE"),
            # Для кредитных карт заполняем пустые значения бесконечностью
            pl.when(pl.col('LOAN_TYPE').is_in([7, 8, 24, 36, 37, 38]) & pl.col("FINAL_PMT_DATE").is_null())
                .then(pl.date(9999, 12, 31))
                .otherwise(pl.col("FINAL_PMT_DATE"))
                .alias("FINAL_PMT_DATE"),
        ])

        # Расчет разностей дат в месяцах с датой заявки
        df = df.with_columns([
            pl.col(self.date_column).sub(pl.col(col)).dt.total_days().add(1).truediv(30)
                .clip(-360, 360)
                .alias(f'DIFF_{self.date_column}_{col}')
            for col in self.date_columns
        ])

        # Расчет разностей дат в месяцах с датой открытия
        df = df.with_columns([
            pl.col(col).sub(pl.col(self.open_date_column)).dt.total_days().add(1).truediv(30)
                .clip(0, 360)
                .alias(f'DIFF_{col}_{self.open_date_column}')
            for col in self.date_columns 
            if col not in [self.open_date_column]
        ])

        # final_pmt_date_column = 'FINAL_PMT_DATE'
        # # Расчет разностей дат в месяцах с датой закрытия
        # df = df.with_columns([
        #     pl.col(col).sub(pl.col(final_pmt_date_column)).dt.total_days().add(1).truediv(30)
        #         .clip(0, 360)
        #         .alias(f'DIFF_{col}_{final_pmt_date_column}')
        #     for col in self.date_columns 
        #     if col not in [final_pmt_date_column]
        # ])

        # Расчет отношений фичей 
        df = df.with_columns([
            # C датами
            pl.when(pl.col('DIFF_FINAL_PMT_DATE_OPEN_DATE').eq(0))
                .then(None)
                .otherwise(pl.col('DIFF_FACT_CLOSE_DATE_OPEN_DATE').truediv(pl.col('DIFF_FINAL_PMT_DATE_OPEN_DATE'))
                           .clip(0, 100).fill_nan(None))
                .alias('FACT_CLOSE_DATE_TO_FINAL_PMT_DATE'),
            pl.when(pl.col('DIFF_FINAL_PMT_DATE_OPEN_DATE').eq(0))
                .then(None)
                .otherwise(pl.col('DIFF_APPLICATION_DAY_OPEN_DATE').truediv(pl.col('DIFF_FINAL_PMT_DATE_OPEN_DATE'))
                           .clip(0, 100).fill_nan(None))
                .alias('APPLICATION_DAY_TO_FINAL_PMT_DATE'),
            # C суммами
            pl.when(pl.col('CREDIT_LIMIT').eq(0))
                .then(None)
                .otherwise(pl.col('OUTSTANDING').truediv(pl.col('CREDIT_LIMIT'))
                           .clip(0, 100).fill_nan(None))
                .alias('UTILIZATION'),
        ] + [ # C оставшейся непогашенной задолженностью
            pl.when(pl.col('OUTSTANDING').eq(0))
                .then(None)
                .otherwise(pl.col(feature).truediv(pl.col('OUTSTANDING'))
                           .clip(0, 100).fill_nan(None))
                .alias(f'{feature}_TO_{"OUTSTANDING"}')
            for feature in ['EST_NEXT_PMT', 'EST_CURR_BALANCE_AMT', 'CURR_BALANCE_AMT', 'DELQ_BALANCE', 'MAX_DELQ_BALANCE']
        ] + [ # C лимитом
            pl.when(pl.col('CREDIT_LIMIT').eq(0))
                .then(None)
                .otherwise(pl.col(feature).truediv(pl.col('CREDIT_LIMIT'))
                           .clip(0, 100).fill_nan(None))
                .alias(f'{feature}_TO_{"CREDIT_LIMIT"}')
            for feature in ['EST_NEXT_PMT', 'EST_CURR_BALANCE_AMT', 'CURR_BALANCE_AMT', 'DELQ_BALANCE', 'MAX_DELQ_BALANCE']
        ] + [ # C ежемесячным платежом
            pl.when(pl.col('EST_NEXT_PMT').eq(0))
                .then(None)
                .otherwise(pl.col(feature).truediv(pl.col('EST_NEXT_PMT'))
                           .clip(0, 100).fill_nan(None))
                .alias(f'{feature}_TO_{"EST_NEXT_PMT"}')
            for feature in ['EST_CURR_BALANCE_AMT', 'CURR_BALANCE_AMT', 'DELQ_BALANCE', 'MAX_DELQ_BALANCE']
        ])
        
        df = df.with_columns([
            # Перевернутая платежная строка
            pl.col("PMT_STRING_84M").str.reverse().alias('PMT_STRING_REV_84M')
        ]).with_columns([
            # Обрезаем на периоды платежную строку и убираем символы X из начала платежной строки
            pl.col("PMT_STRING_84M").str.slice(0,  3).str.strip_chars_start("X").alias("PMT_STRING_3M" ),
            pl.col("PMT_STRING_84M").str.slice(0,  6).str.strip_chars_start("X").alias("PMT_STRING_6M" ),
            pl.col("PMT_STRING_84M").str.slice(0, 12).str.strip_chars_start("X").alias("PMT_STRING_12M"),
            # pl.col("PMT_STRING_84M").str.slice(0, 24).str.strip_chars_start("X").alias("PMT_STRING_24M"),
            # pl.col("PMT_STRING_84M").str.slice(0, 36).str.strip_chars_start("X").alias("PMT_STRING_36M"),
            pl.col("PMT_STRING_84M").str.strip_chars_start("X").alias("PMT_STRING_84M"),

            # Новые фичи (перевернутая платежная строка)
            pl.col("PMT_STRING_REV_84M").str.slice(0,  3).str.strip_chars_start("X").alias("PMT_STRING_REV_3M" ),
            pl.col("PMT_STRING_REV_84M").str.slice(0,  6).str.strip_chars_start("X").alias("PMT_STRING_REV_6M" ),
            pl.col("PMT_STRING_REV_84M").str.slice(0, 12).str.strip_chars_start("X").alias("PMT_STRING_REV_12M"),
        ])

        # Считаем фичи по платежной строке
        pmt_features = []
        pmt_features_col_names = [
            "PMT_STRING_3M",
            "PMT_STRING_6M",
            "PMT_STRING_12M",
            # "PMT_STRING_24M",
            # "PMT_STRING_36M",
            "PMT_STRING_84M",
            
            'PMT_STRING_REV_3M',
            'PMT_STRING_REV_6M',
            'PMT_STRING_REV_12M',
        ]
        for col in pmt_features_col_names:
            pmt_features.extend([
                pl.col(col).str.count_matches("1").alias(f"{col}_CNT_ON_TIME"),
                pl.col(col).str.count_matches("[EAF2345789]").alias(f"{col}_CNT_DELQ"),
                pl.col(col).str.count_matches("[EAF]").alias(f"{col}_CNT_1_29"),
                pl.col(col).str.count_matches("[2345789]").alias(f"{col}_CNT_30_PLUS"),
                # pl.col(col).str.count_matches("[345789]").alias(f"{col}_CNT_60_PLUS"),
                # pl.col(col).str.count_matches("[45789]").alias(f"{col}_CNT_90_PLUS"),
                pl.col(col).str.count_matches("[78]").alias(f"{col}_CNT_REFIN"),
                # pl.col(col).str.count_matches("9")
                # .alias(f"{col}_CNT_COLL"),
            ])
        df = df.with_columns(pmt_features)

        # Дисконтирование переменных
        df = self.discounter.transform(df)

        # Считаем суммы помноженное на кол-во просрочки или своевременных платежей
        feature = "EST_NEXT_PMT_DCW"
        df = df.with_columns([
            pl.col(feature).mul(pl.col(col)).alias(f'MUL_{feature}_{col}')
            for col in [
                'PMT_STRING_REV_6M_CNT_ON_TIME',
                'PMT_STRING_REV_12M_CNT_ON_TIME',
                
                'PMT_STRING_6M_CNT_ON_TIME',
                'PMT_STRING_12M_CNT_ON_TIME',
                'PMT_STRING_84M_CNT_ON_TIME',
                
                'PMT_STRING_REV_6M_CNT_1_29',
                'PMT_STRING_REV_12M_CNT_1_29',
                
                'PMT_STRING_6M_CNT_1_29',
                'PMT_STRING_12M_CNT_1_29', 
                'PMT_STRING_84M_CNT_1_29',

                'PMT_STRING_REV_6M_CNT_30_PLUS',
                'PMT_STRING_REV_12M_CNT_30_PLUS',
                
                'PMT_STRING_6M_CNT_30_PLUS',
                'PMT_STRING_12M_CNT_30_PLUS', 
                'PMT_STRING_84M_CNT_30_PLUS',
            ]
        ])

        # Считаем от дней просрочки - месяцы просрочки и сумма просрочки
        # f = df.with_columns([pl.col('CURRENT_DELQ').truediv(30).alias('CURRENT_DELQ_MONTH')])
        # df = df.with_columns([pl.col('CURRENT_DELQ_MONTH').mul('EST_NEXT_PMT').alias('CURR_DELQ_AMT')])

        # Маппинг типа кредита в крупные категории
        df = df.with_columns([
            pl.when(pl.col("LOAN_TYPE").is_in([21, 24, 26, 44]) | pl.col("BUSINESS_CATEGORY").is_in([11, 37, 38, 41]))
                .then(pl.lit("MICRO"))
            .when(pl.col("LOAN_TYPE").is_in([1, 42, 43, 48]))
                .then(pl.lit("AUTO"))
            .when(pl.col("LOAN_TYPE").is_in([6, 13, 40, 41, 46, 47]))
                .then(pl.lit("MORTGAGE"))
            .when(pl.col("LOAN_TYPE").is_in([7, 8, 24, 36, 37, 38]))
                .then(pl.lit("CC"))
            # 99 - Неизвестно, но графически подходит
            .when(pl.col("LOAN_TYPE").is_in([9, 10, 11, 12, 16, 22, 33, 34, 39, 99]))
                .then(pl.lit("POTREB"))
            # .when(pl.col("LOAN_TYPE").is_in([10, 11, 12, 16, 22, 33, 34, 39]))
            #     .then(pl.lit("CASH"))
            .otherwise(pl.lit("OTHER")) # (4, 14, 15, 17, 18, 19, 20, 27, 28, 29, 30, 31, 32, 45)
            .alias("LOAN_TYPE_MAP")
        ])

        # Сортировка данных
        return df.sort(self.sort_cols, descending=[False, False, False, False, False, False])
