import polars as pl
from importlib.resources import files

# Load the data files when the module is imported
FEATURE_DESCRIPTION = pl.read_parquet(
    files('generators.feature_info').joinpath('feature_description.parquet.gzip'),
    use_pyarrow=True
)

FILTER_DESCRIPTION = pl.read_parquet(
    files('generators.feature_info').joinpath('filter_description.parquet.gzip'),
    use_pyarrow=True
)

AGGREGATE_DESCRIPTION = pl.read_parquet(
    files('generators.feature_info').joinpath('aggregate_description.parquet.gzip'),
    use_pyarrow=True
)

REGION_DICT = pl.read_parquet(
    files('generators.feature_info').joinpath('region_dict.parquet.gzip'),
    use_pyarrow=True
)

# Optional: Clean up namespace
__all__ = ['FEATURE_DESCRIPTION', 'FILTER_DESCRIPTION', 'AGGREGATE_DESCRIPTION', 'REGION_DICT']