import polars as pl
import warnings
from typing import List, Union, Dict


class Discounter:
    """
    Класс для расчета и применения экспоненциального дисконтирования к нескольким временным признакам.

    Параметры:
        id_column (str): Название колонки с уникальным идентификатором
        date_column (str): Название колонки с датой для временных расчетов
        feature_names (Union[str, List[str]]): Список признаков для дисконтирования. Если передана строка - преобразуется в список
        frequency (str): Временная частота для дисконтирования ('weekly', 'biweekly', 'monthly' или 'yearly')
        start_date (pl.Expr, optional): Начальная дата для расчета дисконтирования. По умолчанию 2018-01-01. 
                                        Для недельных показателей лучше брать понедельник, чтобы дисконтирование на проде обновлялось в пн.
        rolling_period (str, optional): Число периодов для сглаживания временного ряда (оконное скользящее среднее). Смотри агрумент функции period в polars.DataFrame.rolling(). По умолчанию None.
        min_count (int, optional): Минимально необходимое кол-во наблюдений внутри периода (frequency) для фильтрации. По умолчанию None.
        suffix (str, optional): Суффикс для дисконтированных признаков. По умолчанию '_DISC'.
        method (str, optional): Метод подбора коэффициента дистонтирования. Возможные значения: 'beta' (расчет бета-коээфициента) или 'pct_change' (среднее процентное изменение). По умолчанию 'beta'.
        remove_outliers_iqr (bool, optional): Если True, удаляет выбросы из агрегатов с использованием IQR перед расчетом коэффициентов. По умолчанию False.
        iqr_quantiles (tuple, optional): Квантили для учитывания выбросов. По умолчанию (.1, .9).
        iqr_coef (float, optional): Коэффициент для интерквартильного размаха. По умолчанию 1.5.

    Атрибуты:
        rates (Dict[str, float]): Словарь рассчитанных коэффициентов дисконтирования (доступен после обучения)
    """

    def __init__(
        self,
        id_column:           str,
        date_column:         str,
        feature_names:       Union[str, List[str]],
        frequency:           str,
        start_date:          pl.Expr = pl.date(2018, 1, 1),
        rolling_period:      str = None,
        min_count:           int = None,
        suffix:              str = '_DISC',
        method:              str = 'beta',
        remove_outliers_iqr: bool = True,
        iqr_quantiles:       tuple = (.1, .9),
        iqr_coef:            float = 1.5,
    ):
        self.id_column = id_column
        self.date_column = date_column
        self.feature_names = [feature_names] if isinstance(feature_names, str) else feature_names
        self.frequency = frequency
        self.start_date = start_date
        self.rolling_period = rolling_period
        self.min_count = min_count
        self.suffix = suffix
        self.method = method
        self.remove_outliers_iqr = remove_outliers_iqr
        self.iqr_quantiles = iqr_quantiles
        self.iqr_coef = iqr_coef
        self.rates = {}

    def _add_time_column(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Добавляет колонку с временными периодами в зависимости от частоты.
        
        Параметры:
            df (pl.DataFrame): DataFrame с исходными признаками
        """
        if self.frequency.lower() in ('yearly', 'year', 'y'):
            return df.with_columns(
                (pl.col(self.date_column).dt.year() - self.start_date.dt.year() + 1)
                .alias('time')
            )
        elif self.frequency.lower() in ('monthly', 'month', 'm'):
            return df.with_columns(
                ((pl.col(self.date_column).dt.year() - self.start_date.dt.year()) * 12 
                 + pl.col(self.date_column).dt.month())
                .alias('time')
            )
        elif self.frequency.lower() in ('biweekly', 'biweek', 'bw'):
            return df.with_columns(
                ((pl.col(self.date_column) - self.start_date).dt.total_days() // 14 + 1)
                .alias('time')
            )
        elif self.frequency.lower() in ('weekly', 'week', 'w'):
            return df.with_columns(
                ((pl.col(self.date_column) - self.start_date).dt.total_days() // 7 + 1)
                .alias('time')
            )
        else:
            raise ValueError("Частота должна быть 'weekly', 'biweekly', 'monthly' или 'yearly'.")

    def fit(self, df: pl.DataFrame) -> 'Discounter':
        """
        Вычисляет коэффициенты дисконтирования для всех признаков.
        - method = `beta` использует линейную регрессию на логарифмированных средних значениях.
        - method = `pct_change` вычисляет средний прирост по признакам.

        Параметры:
            df (pl.DataFrame): DataFrame с исходными признаками
        
        Исключения:
            ValueError: Если для любого признака недостаточно данных или нулевая дисперсия времени
        """
        df = self._add_time_column(df)

        exprs = [pl.col(f).filter(pl.col(f) > 0).mean().alias(f"{f}_mean") for f in self.feature_names]
        if self.min_count is not None:
            exprs += [pl.col(f).filter(pl.col(f) > 0).count().alias(f"{f}_count") for f in self.feature_names]
        
        aggregated = df.group_by('time').agg(exprs).sort('time')
        
        for feature in self.feature_names:
            mean_col  = f"{feature}_mean"
            
            if self.min_count is not None:
                count_col = f"{feature}_count"
                feature_data = aggregated.select(['time', mean_col, count_col]).drop_nulls()\
                               .filter(pl.col(count_col).ge(self.min_count)).drop(count_col)
            else:
                feature_data = aggregated.select(['time', mean_col]).drop_nulls()

            if self.rolling_period is not None:
                feature_data = feature_data.rolling(index_column='time', period=self.rolling_period)\
                               .agg(pl.all().mean())
            
            # Удаление выбросов по IQR
            if self.remove_outliers_iqr:
                feature_data = self._remove_outliers_iqr(feature_data, mean_col)

            if len(feature_data) < 2:
                raise ValueError(
                    f"Недостаточно данных для '{feature}'. Требуется минимум 2 временных периода с положительными значениями."
                )

            if self.method.lower() in ('beta', 'regression'):
                feature_data = feature_data.with_columns(
                    pl.col(mean_col).log().alias('ln_mean')
                )
                
                stats = feature_data.select(
                    pl.cov('time', 'ln_mean').alias('covariance'),
                    pl.var('time').alias('variance')
                )
                
                covariance = stats['covariance'][0]
                variance = stats['variance'][0]
                
                if variance == 0:
                    raise ValueError(f"Нулевая дисперсия времени для '{feature}'. Проверьте расчет временной колонки.")
                
                # Calculate rate and add warning
                rate = covariance / variance

            elif self.method.lower() in ('pct', 'percent', 'pct_change'):
                rate = feature_data.select(pl.col(mean_col).pct_change(1).fill_null(0)).mean()[0, 0]

            else:
                raise ValueError('Неправильный аргумент `self.method`. Возможные значения: "beta" или "pct_change".')
            
            if rate < 0:
                warnings.warn(
                    f"\nОтрицательный коэффициент дисконтирования ({rate:.4f}) для признака '{feature}'!\n"
                    "Это может привести к увеличению значений со временем вместо ожидаемого уменьшения.\n"
                    "Проверьте:\n"
                    "1. Достаточно ли данных для расчета\n"
                    "2. Корректность временных периодов\n"
                    "3. Логику бизнес-показателей",
                    UserWarning
                )
            
            self.rates[feature] = rate
            
        return self

    def transform(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Применяет коэффициенты дисконтирования ко всем признакам и добавляет в исходный датафрейм

        Параметры:
            df (pl.DataFrame): DataFrame с исходными признаками
        """
        if not self.rates:
            raise ValueError("Коэффициенты не найдены. Сначала выполните fit() или set_rates().")
            
        df = self._add_time_column(df)
        
        for feature, rate in self.rates.items():
            df = df.with_columns(
                (pl.col(feature) * (1 + rate) ** (-pl.col('time'))
                ).alias(f"{feature}{self.suffix}")
            )
            
        return df.drop('time')

    def set_rates(self, rates: Union[float, Dict[str, float]]) -> 'Discounter':
        """
        Ручная установка коэффициентов дисконтирования.
        
        Аргументы:
            rates: Может быть числом (применяется ко всем признакам)
                   или словарем {признак: коэффициент}
        """
        if isinstance(rates, float):
            self.rates = {f: rates for f in self.feature_names}
        else:
            missing = set(self.feature_names) - set(rates.keys())
            if missing:
                raise ValueError(f"Отсутствуют коэффициенты для признаков: {missing}")
            self.rates = rates.copy()
        return self

    def fit_transform(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Удобный метод для одновременного обучения и преобразования.

        Параметры:
            df (pl.DataFrame): DataFrame с исходными признаками
        """
        return self.fit(df).transform(df)

    def _aggregate(self, df: pl.DataFrame, features: list = None) -> pl.DataFrame:
        """
        Агрегация с добавлением минимальной даты периода

        Параметры:
            df (pl.DataFrame): DataFrame с исходными признаками
            features: (list, optional): Фичи для аггрегации. Если None, то беруться исходные и дисконтированные фичи. По умолчанию None. 
        """
        if features is None:
            features = [f for f in self.feature_names] + [f + self.suffix for f in self.feature_names]

        # Проверка наличия признаков
        for feature in features:
            if feature not in df.columns:
                raise ValueError(f"Признак {feature} отсутствует.")
                
        df_with_time = self._add_time_column(df)
        
        agg_exprs =\
            [pl.col(self.date_column).min().alias('period_date')] +\
            [pl.when(pl.col(f).gt(0)).then(pl.col(f)).otherwise(None).mean() for f in features]
        
        aggregated = df_with_time.group_by("time").agg(agg_exprs).sort("time")
        
        return aggregated

    def _remove_outliers_iqr(self, df: pl.DataFrame, feature: str) -> pl.DataFrame:
        q1, q3 = df.select(
            pl.col(feature).quantile(self.iqr_quantiles[0]).alias('q1'),
            pl.col(feature).quantile(self.iqr_quantiles[1]).alias('q3')
        ).row(0)
        iqr = q3 - q1
        lower_bound = q1 - self.iqr_coef * iqr
        upper_bound = q3 + self.iqr_coef * iqr
        return df.filter(
            (pl.col(feature) >= lower_bound) & 
            (pl.col(feature) <= upper_bound)
        )

    def plot(self, df: pl.DataFrame, figsize: tuple = (12, 4), remove_outliers_iqr: bool = False) -> None:
        """
        Визуализирует исходные и дисконтированные признаки по временным периодам.
    
        Параметры:
            df (pl.DataFrame): DataFrame с исходными и дисконтированными признаками (после вызова transform())
            figsize (tuple, optional): Размер фигуры
            remove_outliers_iqr (bool, optional): Удалить выбросы на основе IQR
    
        Исключения:
            ValueError: Если дисконтированные признаки отсутствуют в DataFrame
        """
        import matplotlib.pyplot as plt
        import matplotlib.dates as mdates
        
        # Агрегация с добавлением минимальной даты периода
        aggregated = self._aggregate(df)
    
        # Создание отдельных графиков
        for feature in self.feature_names:
            plt.figure(figsize=figsize)
            ax = plt.gca()
            disc_feature = feature + self.suffix

            feature_data = aggregated.select(pl.col(['period_date', feature, disc_feature]))

            # Удаление выбросов по IQR
            if remove_outliers_iqr:
                feature_data = self._remove_outliers_iqr(feature_data, feature) 
            
            # Основные линии
            ax.plot(feature_data['period_date'].to_pandas(), feature_data[feature].to_pandas(), label="Исходный", 
                   color="#1f77b4", marker="o", linewidth=1, markersize=1)
            ax.plot(feature_data['period_date'].to_pandas(), feature_data[disc_feature].to_pandas(), label="Дисконтированный",
                   color="#ff7f0e", marker="s", linestyle="--", linewidth=1, markersize=1)
    
            # Форматирование осей
            ax.xaxis.set_major_locator(mdates.MonthLocator(interval=2))
            ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y-%m'))
            plt.xticks(rotation=45)
            
            ax.set_title(f"Динамика признака: {feature}", pad=12)
            ax.set_xlabel("Дата", labelpad=10)
            ax.set_ylabel("Среднее значение", labelpad=10)
            ax.legend()
            ax.grid(True, alpha=0.3)
            ax.spines[["top", "right"]].set_visible(False)
            plt.tight_layout()
        
        plt.show()
