import polars as pl

try:
    from feature_aggregator import FeatureAggregator
    from base_generator     import BaseGenerator
    from preprocess         import Discounter
except Exception as err:
    from generators.feature_aggregator import FeatureAggregator
    from generators.base_generator     import BaseGenerator
    from generators.preprocess         import Discounter


class InqGenerator(BaseGenerator):
    """Класс для генерации и предобработки кредитных данных.

    Обрабатывает сырые данные: переименование колонок, преобразование типов,
    создание новых признаков (например, из платежной строки), фильтрация и агрегация.

    Attributes:
        id_column (str): Колонка-идентификатор (по умолчанию "APPLICATION_NUMBER").
        date_column (str): Колонка с датой заявки.
        depth_filters (int): Макс. глубина комбинаций фильтров. Для оптимальности используйте значение 3. (по умолчанию 10)
        n_jobs (int): Количество параллельных задач. Для оптимальной скорости используйте значение 4. (по умолчанию 1)
        verbose (bool): Флаг вывода прогресса.
        mask (Tuple[bool]): Маска для фильтрации признаков.
        cast_dtypes (bool): Флаг приведения типов в предобработке (по умолчанию True)
        config (Dict): Готовый конфиг
        old_new_mapping (bool): Использовать ли общий маппинг (old + new) (по умолчанию False)
        keep_eqf (bool): Оставить данные Эквифакс и привести к формату до 2022-11 (по умолчанию True)
    """
    numeric_columns = [
        "INQ_AMT_DCW",
        "INQ_AMT",
        "INQ_QUANTITY",
    ]
    category_num_columns = [
        "INQ_OWN",
    ]
    category_str_columns = [
        "INQ_PERIOD",
        "INQ_PURPOSE",
        "INQ_TYPE",
        "INQ_SOURCE",
        "INQ_CURRENCY",
        # "INQ_CURRENCY_MAP",
        # "INQ_PURPOSE_MAP",
        # "INQ_PERIOD_MAP",
    ]
    date_columns = [
        "INQ_DATE",
    ]
    rename_mapping = {
        "REQUESTID":            "REQUESTID",
        "STAGEID":              "STAGEID",
        "APPLICATION_TIME":     "APPLICATION_DAY",
    }
    allowed_filters = {
        "":              FeatureAggregator.make_expr_config("REQUESTID", "is_not_null", ""), # пустой фильтр
        
        'AMTGE100K':     FeatureAggregator.make_expr_config("INQ_AMT", "ge", "", 100_000),
        'AMTGE50K':      FeatureAggregator.make_expr_config("INQ_AMT", "ge", "", 50_000),
        'AMTGT0':        FeatureAggregator.make_expr_config("INQ_AMT", "gt", "", 0),
        'AMTEQ0':        FeatureAggregator.make_expr_config("INQ_AMT", "eq", "", 0),
        
        'MORTGAGE':      FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '0. MORTGAGE'),
        'AUTO':          FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '1. AUTO'),
        'VIEW':          FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '2. VIEW'),
        'OTHER':         FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '3. OTHER'),
        'CC':            FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '4. CC'),
        'POTREB':        FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '5. POTREB'),
        'MICRO':         FeatureAggregator.make_expr_config("INQ_PURPOSE_MAP", "eq", "", '6. MICRO'),
        
        # 'MTSB':          FeatureAggregator.make_expr_config("INQ_OWN", "eq", "", 1),
        # 'notMTSB':       FeatureAggregator.make_expr_config("INQ_OWN", "ne", "", 1),
        
        '14D':           FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "0. 14"),
        '30D':           FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "1. 30"),
        '60D':           FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "2. 60"),
        '90D':           FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "3. 90"),
        '180D':          FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "4. 180"),
        '365D':          FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "5. 365"),
        '365D_PLUS':     FeatureAggregator.make_expr_config("INQ_PERIOD_MAP", "eq", "", "6. 365+"),
        
        # 'OKB':           FeatureAggregator.make_expr_config("INQ_SOURCE", "eq", "", "okb"),
        # 'NBKI':          FeatureAggregator.make_expr_config("INQ_SOURCE", "eq", "", "nbki"),
        'EQF':           FeatureAggregator.make_expr_config("INQ_SOURCE", "eq", "", "eqf"),
        'notEQF':        FeatureAggregator.make_expr_config("INQ_SOURCE", "ne", "", "eqf"),
        # 'notRUB':        FeatureAggregator.make_expr_config("INQ_CURRENCY_MAP", "ne", "", '1. RUB'),
        # 'RUB':           FeatureAggregator.make_expr_config("INQ_CURRENCY_MAP", "eq", "", '1. RUB'),
    }
    allowed_num_aggregations = (
        lambda column: FeatureAggregator.make_expr_config(column, "count", "")                | {"function_alias": "count"}, # Убрал, т.к. зависит от кол-ва пришедших бюро
        lambda column: FeatureAggregator.make_expr_config(column, "sum", "")                  | {"function_alias": "sum"},   # Убрал, т.к. зависит от кол-ва пришедших бюро
        lambda column: FeatureAggregator.make_expr_config(column, "last_not_null", "bki_gen") | {"function_alias": "last"},
        lambda column: FeatureAggregator.make_expr_config(column, "mean", "")                 | {"function_alias": "mean"},
        lambda column: FeatureAggregator.make_expr_config(column, "quantile", "", .10)        | {"function_alias": "q10"},
        lambda column: FeatureAggregator.make_expr_config(column, "median", "")               | {"function_alias": "median"},
        lambda column: FeatureAggregator.make_expr_config(column, "quantile", "", .90)        | {"function_alias": "q90"},
        # lambda column: FeatureAggregator.make_expr_config(column, "max", "")                  | {"function_alias": "max"},   # Заменили на q10
        # lambda column: FeatureAggregator.make_expr_config(column, "min", "")                  | {"function_alias": "min"},   # Заменили на q90
        # lambda column: FeatureAggregator.make_expr_config(column, "std", "")                  | {"function_alias": "std"},   # Плохо интерпретируется
    )
    old_new_purpose_mapper = {
        '1' : '1. AUTO',
        '50': '2. VIEW',
        '23': '2. VIEW',
        '27': '2. VIEW',
        '28': '2. VIEW',
        '25': '3. OTHER',
        '29': '3. OTHER',
        '30': '3. OTHER',
        '99': '3. OTHER',
        '4' : '4. CC',
        '7' : '4. CC',
        '8' : '4. CC',
        '3' : '5. POTREB',
        '5' : '5. POTREB',
        '9' : '5. POTREB',
        '17': '5. POTREB',
        '18': '5. POTREB',
        '19': '5. POTREB',
        '22': '5. POTREB',
        '6' : '0. MORTGAGE',
        '20': '0. MORTGAGE',
        # '7' : '0. MORTGAGE',
        '2' : '6. MICRO',
        '21': '6. MICRO',
        '26': '6. MICRO',
    }
    new_purpose_mapper = {
        '20': '0. MORTGAGE', # NEW
        '7' : '0. MORTGAGE', # NEW
        '1' : '1. AUTO',     # NEW / OLD
        '23': '2. VIEW',     # NEW
        '27': '2. VIEW',     # NEW
        '25': '3. OTHER',    # NEW
        '99': '3. OTHER',    # NEW / OLD
        '4' : '4. CC',       # NEW
        '3' : '5. POTREB',   # NEW
        '5' : '5. POTREB',   # NEW
        '9' : '5. POTREB',   # NEW / OLD
        '2' : '6. MICRO',    # NEW
    }
    old_purpose_mapper = {
        '6' : '0. MORTGAGE',  # OLD
        '1' : '1. AUTO',      # NEW / OLD
        '50': '2. VIEW',      # OLD
        '23': '2. VIEW',      # NEW
        '27': '2. VIEW',      # NEW
        '28': '2. VIEW',      # OLD
        '29': '3. OTHER',     # OLD
        '30': '3. OTHER',     # OLD
        '99': '3. OTHER',     # NEW / OLD
        '7' : '4. CC',        # OLD
        '8' : '4. CC',        # OLD
        '3' : '5. POTREB',    # NEW / OLD
        '9' : '5. POTREB',    # NEW / OLD
        '17': '5. POTREB',    # OLD
        '18': '5. POTREB',    # OLD
        '19': '5. POTREB',    # OLD
        '22': '5. POTREB',    # OLD
        '21': '6. MICRO',     # OLD
        '26': '6. MICRO',     # OLD
    }
    inq_period_mapper = {
        "7":    "0. 14",
        "14":   "0. 14",
        "21":   "1. 30",
        "30":   "1. 30",
        "60":   "2. 60",
        "90":   "3. 90",
        "180":  "4. 180",
        "270":  "5. 365",
        "365":  "5. 365",
        "365+": "6. 365+",
    }
    sort_cols = {
        'INQ_PERIOD_MAP': True,
        'INQ_DATE': False,
        'INQ_CURRENCY_MAP': False,
        'INQ_SOURCE': False,
        'INQ_PURPOSE_MAP': False,
        'INQ_TYPE': False,
        'INQ_AMT': False,
        'INQ_QUANTITY': False,
    }

    def __init__(
        self,
        id_column:        str  = "APPLICATION_NUMBER",
        date_column:      str  = "APPLICATION_DAY",
        depth_filters:    int  = 10,
        n_jobs:           int  = 1,
        verbose:          bool = False,
        cast_dtypes:      bool = True,
        config:           dict = None,
        old_new_mapping:  bool = False,
        keep_eqf:         bool = True,
    ):
        """Инициализация InqGenerator."""
        # Исключить генерацию недисконтированных фичей
        black_list = [
            # "INQ_AMT",
        ]
        numeric_columns = [col for col in self.numeric_columns if col not in black_list]
        
        super().__init__(
            id_column,
            date_column,
            depth_filters,
            self.allowed_filters,
            numeric_columns, # self.numeric_columns,
            self.allowed_num_aggregations,
            verbose,
            cast_dtypes,
            n_jobs,
            config,
        )

        discount_rates = {
            'INQ_AMT': 0.001453,
        }
        self.discounter = Discounter(
            id_column, 
            date_column, 
            list(discount_rates.keys()), 
            'weekly',
            rolling_period='12i',
            suffix='_DCW',
            method='beta',
        ).set_rates(discount_rates)
        
        self.old_new_mapping = old_new_mapping
        self.keep_eqf        = keep_eqf
        
    def preprocess(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Предобработка признаков inq.
        Метод preprocess выполняет следующие операции:
        - Переименование колонок согласно предварительному сопоставлению.
        - Приведение типов для колонок с датами, числовых и категориальных данных.
        - Применение фильтрации, основанной на значениях колонок INQ_SOURCE и INQ_PERIOD.
        - Применение преобразований для создания новых признаков (например, маппинг валют и назначения целей).
        """

        df = df.unique().rename(self.rename_mapping)

        if self.cast_dtypes:
            # Преобразование типов
            df = df.with_columns([ 
                # Преобразование типов для дат
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                    .str.strptime(pl.Datetime).dt.truncate("1d")
                for col in [self.date_column] + self.date_columns
                if col in df.columns and col not in ('INQ_DATE')
            ] + [ 
                # Преобразование типов для численных и категориально-численных признаков
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                    .cast(pl.Float32)
                for col in self.numeric_columns + self.category_num_columns
                if col in df.columns
            ] + [ 
                # Преобразование типов для категориальных признаков
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                for col in self.category_str_columns + ["INQ_DATE"]
                if col in df.columns
            ])
            
        # df = df.filter(pl.col("INQ_OWN").ne(1))
        with_columns_expr = [
            # ex inq_dataframe function
            # NaN_RUR ~ eqf, NaN_RUB ~ okb + nbki
            # pl.when(pl.col('INQ_SOURCE').is_null() & pl.col('INQ_CURRENCY').eq('RUR'))
            #     .then(pl.lit('NaN_RUR'))
            pl.when(pl.col('INQ_SOURCE').is_null() & pl.col('INQ_CURRENCY').eq('RUB'))
                .then(pl.lit('okb'))
                .otherwise(pl.col('INQ_SOURCE'))
                .alias('INQ_SOURCE'),
            pl.col('INQ_PERIOD')
                .replace_strict(self.inq_period_mapper, default=None)
                .alias('INQ_PERIOD_MAP'),
            pl.col('INQ_AMT')
                .cast(pl.Float32)
                # После нового формата появились NaN
                .fill_null(0),
            pl.col('INQ_QUANTITY')
                .cast(pl.Int32)
                .fill_null(0),
            # Начал заполняться с 2023-08-16
            pl.col('INQ_DATE')
                .cast(pl.Float64)
                .cast(pl.String)
                .str.pad_start(10, '0')
                .str.slice(0, 8)
                .str.to_date("%d%m%Y", strict=True),
            pl.when(pl.col('INQ_CURRENCY').is_in(['RUB', 'RUR']))
                .then(pl.lit('1. RUB'))
                .otherwise(pl.lit('0. OTHER'))
                .alias('INQ_CURRENCY_MAP'),
            # ex inq_purpose_map function
            # Преобразование маппинга: https://jira.mtsbank.ru/browse/DS-532
            pl.when(self.old_new_mapping)
                # Двойной (старый + новый) Маппинг
                .then(pl.col('INQ_PURPOSE').replace_strict(self.old_new_purpose_mapper, default=None).fill_null('3. OTHER'))
                # Иначе маппинг по датам
                .otherwise(
                    pl.when(
                            pl.col('INQ_SOURCE').is_in(['okb', 'nbki', 'eqf']) &
                            pl.col('INQ_DATE').is_not_null() &
                            pl.col(self.date_column).ge(pl.date(2023, 8, 16))
                        )
                        # Новый Маппинг
                        .then(pl.col('INQ_PURPOSE').replace_strict(self.new_purpose_mapper, default=None).fill_null('3. OTHER'))
                        # Старый Маппинг
                        .otherwise(pl.col('INQ_PURPOSE').replace_strict(self.old_purpose_mapper, default=None).fill_null('3. OTHER'))
                )
                .alias('INQ_PURPOSE_MAP')
        ]

        if 'INQ_TYPE' in df.columns:
            # Заполняется с 2024-09
            with_columns_expr.append(pl.col('INQ_TYPE').cast(pl.Int8, strict=False))
        
        df = df.filter(
            # Не убираем Эквифакс
            # pl.col('INQ_SOURCE').is_in(['okb', 'nbki']) &
            ~(pl.col('INQ_SOURCE').is_null() & pl.col('INQ_CURRENCY').eq('RUR')) &
            pl.col('INQ_PERIOD').is_not_null()
        ).with_columns(with_columns_expr)

        sort_cols = [k for k in self.sort_cols.keys() if k in df.columns]
        sort_desc = [v for k, v in self.sort_cols.items() if k in df.columns]
        
        if self.keep_eqf:
            # Функция inq_convert_eqf. Оставляем только 4 inq_period и по ним сводим

            agg_expr = [pl.all().exclude(['INQ_QUANTITY', 'INQ_OWN']).first(), pl.col('INQ_QUANTITY').sum()]
            if 'INQ_OWN' in df.columns:
                agg_expr.append(pl.col('INQ_OWN').max())
            
            df_eqf = df.filter(pl.col('INQ_SOURCE').is_in(['eqf']))\
                .with_columns(
                    pl.col('INQ_PERIOD_MAP').replace({"2. 60": "3. 90", "4. 180": "5. 365", "6. 365+": "5. 365"})
                ).sort(sort_cols, descending=sort_desc)\
                .group_by([self.id_column, self.date_column, 'INQ_PERIOD_MAP'])\
                .agg(agg_expr)
    
            df = pl.concat([df.filter(pl.col('INQ_SOURCE').is_in(['okb', 'nbki'])), df_eqf[df.columns]])
        else:
            df = df.filter(pl.col('INQ_SOURCE').is_in(['okb', 'nbki']))

        # Дисконтирование переменных
        df = self.discounter.transform(df)

        return df.sort(sort_cols, descending=sort_desc)
