import polars as pl

try:
    from feature_aggregator import FeatureAggregator
    from base_generator import BaseGenerator
except Exception as err:
    from generators.feature_aggregator import FeatureAggregator
    from generators.base_generator import BaseGenerator


class OverviewGenerator(BaseGenerator):
    """Класс для генерации и предобработки кредитных данных.

    Обрабатывает сырые данные: переименование колонок, преобразование типов,
    создание новых признаков (например, из платежной строки), фильтрация и агрегация.

    Attributes:
        id_column (str): Колонка-идентификатор (по умолчанию "APPLICATION_NUMBER").
        date_column (str): Колонка с датой заявки.
        depth_filters (int): Макс. глубина комбинаций фильтров. Для оптимальности используйте значение 3. (по умолчанию 10)
        n_jobs (int): Количество параллельных задач. Для оптимальной скорости используйте значение 4. (по умолчанию 1)
        verbose (bool): Флаг вывода прогресса.
        mask (Tuple[bool]): Маска для фильтрации признаков.
        cast_dtypes (bool): Флаг приведения типов в предобработке (по умолчанию True)
        config (Dict): Готовый конфиг
    """
    numeric_columns = [
        'LOAN_MAIN_BORROWER', 
        'TTL_ACCOUNTS', 'TTL_CONSUMER',
        'TTL_MORTGAGE', 'TTL_CREDIT_CARD', 'TTL_AUTO_LOAN',
        'TTL_OFFICIALS', 'TTL_LEGALS', 'TTL_BANKRUPTCIES',
        'TTL_DISPUTED_ACCOUNTS', 'TTL_DISPUTED_LEGALS',
        'TTL_DISPUTED_OFFICIALS',
        # 'TTL_DELQ_5',
        # 'TTL_DELQ_5_29',
        # 'TTL_DELQ_30_59', 
        # 'TTL_DELQ_60_89',
        # 'TTL_DELQ_90_PLUS',
        'TTL_INQUIRIES', 'INQUIRY_1_WEEK', 'INQUIRY_1_MONTH',
        'INQUIRY_3_MONTH', 'INQUIRY_6_MONTH', 'INQUIRY_9_MONTH',
        'INQUIRY_12_MONTH', 'INQUIRY_RECENT_PERIOD',
        
        'TTL_DELQ_30_L12M',
        'TTL_DELQ_30_59_L12M',
        'TTL_DELQ_60_89_L12M',
        'TTL_DELQ_90_PLUS_L12M',
        
        'CNT_MONTH_LAST_CRED',
        'CNT_MONTH_FIRST_CRED',

        'IS_CREDS_NEGATIVE', 
        'IS_CREDS_59_PLUS_12M', 
        'IS_CREDS_30_59_TWICE_12M', 
        'IS_CREDS_30_59_ONCE_12M',
        'IS_CREDS_5_29_3TIMES_12M',
        'IS_CREDS_ACTIVE_CREDS_6M',

        'MAX_OVERDUE_STATUS_MAP',
        'WORST_STATUS_EVER_MAP',
    ]
    category_num_columns = []
    category_str_columns = [
        'MAX_OVERDUE_STATUS',
        'WORST_STATUS_EVER',
    ]
    date_columns = [
        'LAST_LOAN_DATE',
        'FIRST_LOAN_DATE'
    ]
    rename_mapping = {
        "REQUESTID":            "REQUESTID",
        "STAGEID":              "STAGEID",
        "APPLICATION_DAY":      "APPLICATION_DAY",

        'LOAN_MAIN_BORROWER': 'LOAN_MAIN_BORROWER',
        'TTL_ACCOUNTS': 'TTL_ACCOUNTS',
        'TTL_CONSUMER': 'TTL_CONSUMER',
        'TTL_MORTGAGE': 'TTL_MORTGAGE',
        'TTL_CREDIT_CARD': 'TTL_CREDIT_CARD',
        'TTL_AUTO_LOAN': 'TTL_AUTO_LOAN',
        'TTL_OFFICIALS': 'TTL_OFFICIALS',
        'TTL_LEGALS': 'TTL_LEGALS',
        'TTL_BANKRUPTCIES': 'TTL_BANKRUPTCIES',
        'TTL_DISPUTED_ACCOUNTS': 'TTL_DISPUTED_ACCOUNTS',
        'TTL_DISPUTED_LEGALS': 'TTL_DISPUTED_LEGALS',
        'TTL_DISPUTED_OFFICIALS': 'TTL_DISPUTED_OFFICIALS',
        'TTL_DELQ_5': 'TTL_DELQ_5',
        'TTL_DELQ_5_29': 'TTL_DELQ_5_29',
        'TTL_DELQ_30_59': 'TTL_DELQ_30_59',
        'TTL_DELQ_60_89': 'TTL_DELQ_60_89',
        'TTL_DELQ_90_PLUS': 'TTL_DELQ_90_PLUS',
        'TTL_INQUIRIES': 'TTL_INQUIRIES',
        'INQUIRY_1_WEEK': 'INQUIRY_1_WEEK',
        'INQUIRY_1_MONTH': 'INQUIRY_1_MONTH',
        'INQUIRY_3_MONTH': 'INQUIRY_3_MONTH',
        'INQUIRY_6_MONTH': 'INQUIRY_6_MONTH',
        'INQUIRY_9_MONTH': 'INQUIRY_9_MONTH',
        'INQUIRY_12_MONTH': 'INQUIRY_12_MONTH',
        'INQUIRY_RECENT_PERIOD': 'INQUIRY_RECENT_PERIOD',
        'CRITERIA_1':'IS_CREDS_NEGATIVE', 
        'CRITERIA_2':'IS_CREDS_59_PLUS_12M', 
        'CRITERIA_3':'IS_CREDS_30_59_TWICE_12M', 
        'CRITERIA_4':'IS_CREDS_30_59_ONCE_12M',
        'CRITERIA_5':'IS_CREDS_5_29_3TIMES_12M',
        'CRITERIA_6':'IS_CREDS_ACTIVE_CREDS_6M',
        'TTL_DELQ_30_L12M': 'TTL_DELQ_30_L12M',
        'TTL_DELQ_30_59_L12M': 'TTL_DELQ_30_59_L12M',
        'TTL_DELQ_60_89_L12M': 'TTL_DELQ_60_89_L12M',
        'TTL_DELQ_90_PLUS_L12M': 'TTL_DELQ_90_PLUS_L12M',
        'MAX_OVERDUE_STATUS': 'MAX_OVERDUE_STATUS',
        'WORST_STATUS_EVER': 'WORST_STATUS_EVER',
        'CNT_MONTH_LAST_CRED': 'CNT_MONTH_LAST_CRED',
        'CNT_MONTH_FIRST_CRED': 'CNT_MONTH_FIRST_CRED',
    }
    

    allowed_filters = {
        "": FeatureAggregator.make_expr_config("REQUESTID", "is_not_null", ""),
    }
    allowed_num_aggregations = (
        lambda column: FeatureAggregator.make_expr_config(column, "max", "") | {"function_alias": ""},
    )
    status_dict = {'X': 0, '0': 1, '1': 2, 'B': 3, 'A': 4, 'C': 5, '2': 6, '3': 7, '4': 8, '5': 9, '7': 10, '8': 11, '9': 12}

    def __init__(
        self,
        id_column:        str  = "APPLICATION_NUMBER",
        date_column:      str  = "APPLICATION_DAY",
        depth_filters:    int  = 10,
        n_jobs:           int  = 1,
        verbose:          bool = False,
        cast_dtypes:      bool = True,
        config:           dict = None,
    ):
        """Инициализация OverviewGenerator."""
        super().__init__(
            id_column,
            date_column,
            depth_filters,
            self.allowed_filters,
            self.numeric_columns,
            self.allowed_num_aggregations,
            verbose,
            cast_dtypes,
            n_jobs,
            config,
        )
        
    def preprocess(self, df: pl.DataFrame) -> pl.DataFrame:
        """
        Предобработка признаков overview 
        """

        df = df.rename(self.rename_mapping)

        if self.cast_dtypes:
            # Преобразование типов
            df = df.with_columns([ 
                # Преобразование типов для дат
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                    .str.strptime(pl.Datetime).dt.truncate("1d")
                for col in [self.date_column] + self.date_columns
                if col in df.columns
            ] + [ 
                # Преобразование типов для численных и категориально-численных признаков
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                    .cast(pl.Float32)
                for col in self.numeric_columns + self.category_num_columns
                if col in df.columns
            ] + [ 
                # Преобразование типов для категориальных признаков
                pl.col(col).cast(pl.String)
                    .replace(self.alias_null, None)
                for col in self.category_str_columns
                if col in df.columns
            ])

        df = df.with_columns(
            # ex overview_dataframe function
            (pl.col(self.date_column) - pl.col('LAST_LOAN_DATE'))
                .dt.total_days().add(1).truediv(30)
                .cast(pl.Float32)
                .alias('CNT_MONTH_LAST_CRED'),
            (pl.col(self.date_column) - pl.col('FIRST_LOAN_DATE'))
                .dt.total_days().add(1).truediv(30)
                .cast(pl.Float32)
                .alias('CNT_MONTH_FIRST_CRED'),
            pl.col('MAX_OVERDUE_STATUS')
                .replace_strict(self.status_dict, default=None).fill_null(0)
                .cast(pl.Float32)
                .alias('MAX_OVERDUE_STATUS_MAP'),
            pl.col('WORST_STATUS_EVER')
                .replace_strict(self.status_dict, default=None).fill_null(0)
                .cast(pl.Float32)
                .alias('WORST_STATUS_EVER_MAP'),
        )

        df = df.with_columns(pl.selectors.by_name(self.numeric_columns).fill_null(0))
        
        return df
