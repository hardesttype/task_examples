import polars as pl

try:
    from feature_info import FEATURE_DESCRIPTION, FILTER_DESCRIPTION, AGGREGATE_DESCRIPTION
except Exception as err:
    from generators.feature_info import FEATURE_DESCRIPTION, FILTER_DESCRIPTION, AGGREGATE_DESCRIPTION


def make_feature_description_by_name(
    feature_names: list or tuple or pl.Series or pl.DataFrame,
    col_feature_name: str = 'feature_name',
    col_feature_desc: str = 'feature_description',
) -> pl.DataFrame:
    """
    Generate feature descriptions for given feature names by matching them with predefined descriptions.

    Parameters:
    -----------
    feature_names : list or tuple or pl.Series or pl.DataFrame
        The names of features to get descriptions for. Can be provided as:
        - List or tuple of strings
        - Polars Series
        - Polars DataFrame (with column specified by col_feature_name)
    col_feature_name : str, optional
        Name of the column containing feature names (default: 'feature_name')
    col_feature_desc : str, optional
        Name of the column to store feature descriptions (default: 'feature_description')

    Returns:
    --------
    pl.DataFrame
        A DataFrame with two columns:
        - feature_name (or as specified by col_feature_name)
        - feature_description (or as specified by col_feature_desc)

    Notes:
    ------
    - Matches feature names against a predefined FEATURE_DESCRIPTION table
    - Also includes discounted versions of features (with '_DCW' suffix)
    - Maintains original order of input features
    """

    FEATURE_DESCRIPTION_ = FEATURE_DESCRIPTION.unique(subset='feature_name', maintain_order=True)
    FEATURE_DESCRIPTION_ = pl.concat([
        FEATURE_DESCRIPTION_,
        FEATURE_DESCRIPTION_.with_columns(
            pl.col('feature_name') + '_DCW', # Добавляем дисконтированные фичи
        )
    ], how = 'vertical')
    
    if isinstance(feature_names, list) or isinstance(feature_names, tuple):
        feature_names = pl.Series(col_feature_name, feature_names)
    elif isinstance(feature_names, pl.Series):
        feature_names = pl.Series(col_feature_name, feature_names)
    elif isinstance(feature_names, pl.DataFrame):
        feature_names = feature_names[col_feature_name]

    # Джойним по полному совпадению
    feature_description = feature_names.to_frame().join(
        FEATURE_DESCRIPTION_[['feature_name', 'feature_description']],
        left_on = col_feature_name,
        right_on = 'feature_name'
    ).rename({'feature_description': col_feature_desc})\
    [[col_feature_name, col_feature_desc]]
        
    return feature_description

def make_feature_description_by_config(
    config: dict or str,
    col_feature_name: str = 'feature_name',
    col_feature_desc: str = 'feature_description',
) -> pl.DataFrame:
    """
    Generate feature descriptions based on a feature configuration dictionary or JSON file.

    Parameters:
    -----------
    config : dict or str
        Either:
        - A dictionary containing feature configuration with 'aggregations' key
        - Path to a JSON file containing such configuration
    col_feature_name : str, optional
        Name of the column containing feature names (default: 'feature_name')
    col_feature_desc : str, optional
        Name of the column to store feature descriptions (default: 'feature_description')

    Returns:
    --------
    pl.DataFrame
        A DataFrame with two columns:
        - feature_name (or as specified by col_feature_name)
        - feature_description (or as specified by col_feature_desc)

    Notes:
    ------
    - Combines information from multiple sources:
        - Base feature descriptions (FEATURE_DESCRIPTION)
        - Filter descriptions (FILTER_DESCRIPTION)
        - Aggregate function descriptions (AGGREGATE_DESCRIPTION)
    - Feature names are constructed as: "{function_alias}_{column}_{filters}"
    - Also includes discounted versions of features (with '_DCW' suffix)
    - If config is a file path, it will be loaded as JSON
    """
    
    if isinstance(config, str):
        import json
        with open(config, 'r') as f:
            config = json.load(f)
            
    FEATURE_DESCRIPTION_ = FEATURE_DESCRIPTION.unique(subset='feature_name', maintain_order=True)

    feature_descriptions = []
    for agg in config['aggregations']:
        feature_description_ = FEATURE_DESCRIPTION_.filter(
            pl.col('feature_name').eq(agg['column'].replace('_DCW', ''))
        )[0, 'feature_description']
        
        filter_description_ = [FILTER_DESCRIPTION.filter(
            pl.col('filter_name').eq(f)
        )[0, 'filter_description'] for f in agg['filters']]
        filter_description_ = ' '.join(f for f in filter_description_ if isinstance(f, str))
        
        aggregate_description_ = AGGREGATE_DESCRIPTION.filter(
            pl.col('aggregate_name').eq(agg['function_alias'])
        )[0, 'aggregate_description']

        als = agg['function_alias']
        col = agg['column']
        flt = '_'.join(agg['filters'])
        feature_name = f"{als}_{col}_{flt}".strip('_')

        feature_description = (
            aggregate_description_ + ' по показателю "' +
            feature_description_ + '" ' +
            filter_description_
        )

        feature_descriptions.append({
            col_feature_name: feature_name,
            col_feature_desc: feature_description,
        })

    feature_descriptions = pl.DataFrame(feature_descriptions)
        
    return feature_descriptions
