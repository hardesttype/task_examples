from setuptools import setup, find_packages

setup(
    name="generators",
    version="0.1.0",
    description="Feature generators for credit bureau data",
    author="Byshkov Oleg, Razuvaev Nikita",
    author_email="ovbyshov@mtsbank.ru, nrazuvaev@mtsbank.ru",
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'generators.feature_info': ['*.parquet.gzip'],
    },
    install_requires=[
        "polars==1.26.0",
        "numpy==2.1.3",
        "joblib",
    ],
    python_requires=">=3.12",
)