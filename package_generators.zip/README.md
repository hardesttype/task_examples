# Генераторы

Пакет для генерации признаков из данных кредитного бюро. Этот пакет содержит различные генераторы для разных типов данных:

- `LoanGenerator`: Генерирует признаки из данных о кредитах
- `InqGenerator`: Генерирует признаки из данных о запросах
- `OverviewGenerator`: Генерирует признаки из обзорных данных

## Установка

### Из исходного кода
```bash
# Установка из текущей директории
pip install .

# Установка в режиме разработки
pip install -e .
```

### Из wheel-файла
```bash
# Установка из wheel-файла
pip install dist/generators-0.1.0-py3-none-any.whl
```

### Требования
- Python >= 3.12
- polars == 1.26.0
- numpy == 2.1.3
- joblib

## Использование

```python
import polars as pl
from generators.loan_generator import LoanGenerator
from generators.inq_generator import InqGenerator
from generators.overview_generator import OverviewGenerator

# Инициализация генераторов
loan_generator = LoanGenerator(id_column='REQUESTID', depth_filters=3, verbose=True, n_jobs=4)
inquiry_generator = InqGenerator(id_column='REQUESTID', depth_filters=3, verbose=True, n_jobs=4)
overview_generator = OverviewGenerator(id_column='REQUESTID', depth_filters=3, verbose=True, n_jobs=4)

# Загрузка данных
loan_data = pl.read_parquet("path/to/LOAN.parquet")
inq_data = pl.read_parquet("path/to/INQUIRY.parquet")
overview_data = pl.read_parquet("path/to/OVERVIEW.parquet")

# Генерация признаков
features_loan = loan_generator.generate_mask(loan_data, .01).transform(loan_data)
features_inquiry = inquiry_generator.generate_mask(inq_data, .01).transform(inq_data)
features_overview = overview_generator.generate_mask(overview_data, .01).transform(overview_data)
``` 