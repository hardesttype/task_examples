import pandas as pd
import numpy as np

from ptls.preprocessing.base import ColTransformer
from ptls.preprocessing.pandas.col_transformer import ColTransformerPandasMixin


class TextTokenizer(ColTransformerPandasMixin, ColTransformer):
    """Text tokenizer

    Parameters
    ----------
    col_name_original:
        Source column name
    col_name_target:
        Target column name. Transformed column will be placed here
        If `col_name_target is None` then original column will be replaced by transformed values.
    is_drop_original_col:
        When target and original columns are different manage original col deletion.
    tokenizer:
        tokenizer
    """
    def __init__(self,
                 col_name_original: str,
                 col_name_target: str = None,
                 is_drop_original_col: bool = True,
                 tokenizer: object = None,
                 ):
        super().__init__(
            col_name_original=col_name_original,
            col_name_target=col_name_target,
            is_drop_original_col=is_drop_original_col,
        )

        self.tokenizer = tokenizer

    def fit(self, x: pd.DataFrame):
        super().fit(x)
        
        if self.tokenizer is None:
            pd_col = x[self.col_name_original].astype(str).fillna('')
            self.tokenizer = SimpleTokenizer()
            self.tokenizer.fit(pd_col)
        else:
            pass
        
        return self

    def transform(self, x: pd.DataFrame):
        pd_col = x[self.col_name_original].astype(str).fillna('')
        pd_col = pd_col.apply(self.tokenizer.encode)
            
        x = self.attach_column(x, pd_col)
        x = super().transform(x)
        return x
    
    @property
    def dictionary_size(self):
        return self.tokenizer.dictionary_size


class SimpleTokenizer():
    """Fit dictionary and tokenize text input

    Parameters
    ----------
    mapping:
        Dictionary with mapping from charecters to tokens
    """
    def __init__(self,
                 mapping: dict = None):

        self.mapping = mapping
        
    def fit(self, x: pd.Series):

        chars = x.astype(str).apply(list).explode()

        vc = chars.value_counts()

        self.mapping = {k: i + 3 for i, k in enumerate(vc.index)}
        self.mapping['<pad>'] = 0
        self.mapping['<sos>'] = 1
        self.mapping['<eos>'] = 2
        self.mapping['<unk>'] = len(vc) + 3

        return self
    
    def encode(self, text: str):
        return [self.mapping['<sos>']] +\
               [self.mapping.get(char, self.mapping['<unk>']) for char in text] +\
               [self.mapping['<eos>']]

    @property
    def dictionary_size(self):
        return self.mapping['<unk>'] + 1
