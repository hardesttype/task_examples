from typing import Union

import torch
from torch import nn as nn
from torch.nn.utils.rnn import pad_packed_sequence, pack_padded_sequence

from ptls.nn.trx_encoder.noisy_embedding import NoisyEmbedding


class TextEncoder(nn.Module):
    """
    Class description
    Args:
        parameters
    """

    def __init__(self, 
                    vocab_size: int, 
                    embedding_dim: int, 
                    hidden_dim: int, 
                    num_layers: int = 1,
                    batch_first: bool = True,
                    dropout: float = 0,
                    proj_size: int = 0,
                    encoder: Union[str, nn.Module] = 'lstm', 
                    bidirectional: bool = False,
                    embedding: Union[str, nn.Module] = 'noisy_embeddings',
                    padding_idx: int = 0,
                    norm_embeddings: float = None,
                    emb_dropout: float = 0,
                    spatial_dropout: bool = False,
                    embeddings_noise: float = 0,
                    ):
        super(TextEncoder, self).__init__()

        self.vocab_size = vocab_size
        self.batch_first = batch_first
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.proj_size = proj_size
        self.bidirectional = bidirectional

        if type(embedding) is not str:
            self.embedding = embedding
        elif embedding == 'noisy_embeddings':
            self.embedding = NoisyEmbedding(
                vocab_size, 
                embedding_dim, 
                padding_idx,
                max_norm = 1 if norm_embeddings else None,
                noise_scale = embeddings_noise,
                dropout = emb_dropout,
                spatial_dropout = spatial_dropout,
            )
        else:
            self.embedding = nn.Embedding(
                vocab_size, 
                embedding_dim, 
                padding_idx,
            )

        if type(encoder) is not str:
            self.encoder = encoder
        elif encoder == 'lstm':
            self.encoder =  nn.LSTM(
                input_size = embedding_dim, 
                hidden_size = hidden_dim, 
                num_layers = num_layers, 
                batch_first = batch_first, 
                dropout = dropout,
                bidirectional = bidirectional,
                proj_size = proj_size,
            )
        else:
            raise AttributeError(f'incorrect encoder parameter: '
                                f'`encoder` = "{encoder}"')

    def forward(self, x: nn.utils.rnn.PackedSequence, enforce_sorted: bool = False):
        x, x_lengths = pad_packed_sequence(x, batch_first=self.batch_first)
        x = self.embedding(x)
        x = pack_padded_sequence(x, x_lengths, batch_first=self.batch_first, enforce_sorted=enforce_sorted)
        
        if isinstance(self.encoder, nn.LSTM):
            _, (last_hidden, _) = self.encoder(x)
            D, N, H = last_hidden.shape
            last_hidden = torch.transpose(last_hidden, 1, 0).reshape(N, -1)
        else:
            raise NotImplementedError('Outputs for other encoders are not implemented!')
        
        return last_hidden # seq_len, bidirect * num_layers * hidden_size (proj_size)
    
    @property
    def output_size(self):
        if self.proj_size > 0:
            s = self.proj_size * self.num_layers * (self.bidirectional + 1)
        else:
            s = self.hidden_dim * self.num_layers * (self.bidirectional + 1)
        return s
