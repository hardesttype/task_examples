from typing import Union, List

import torch
from torch import nn as nn
from torch.nn.utils.rnn import pad_packed_sequence, pack_padded_sequence, pad_sequence, unpack_sequence, pack_sequence

from ptls.nn.trx_encoder.noisy_embedding import NoisyEmbedding


class TextEncoder(nn.Module):
    """
    Class description
    Args:
        parameters
    """

    def __init__(self, 
                    vocab_size: int, 
                    embedding_dim: int, 
                    hidden_dim: int, 
                    num_layers: int = 1,
                    batch_first: bool = True,
                    dropout: float = 0,
                    proj_size: int = 0,
                    encoder: Union[str, nn.Module] = 'lstm', 
                    encoder_type: str = 'local', 
                    use_truncated_text: bool = False,
                    mapping: dict = None,
                    bidirectional: bool = False,
                    embedding: Union[str, nn.Module] = 'noisy_embeddings',
                    padding_idx: int = 0,
                    norm_embeddings: float = None,
                    emb_dropout: float = 0,
                    spatial_dropout: bool = False,
                    embeddings_noise: float = 0,
                    ):
        super(TextEncoder, self).__init__()

        self.vocab_size = vocab_size
        self.batch_first = batch_first
        self.hidden_dim = hidden_dim
        self.num_layers = num_layers
        self.proj_size = proj_size
        self.encoder_type = encoder_type
        self.use_truncated_text = use_truncated_text
        self.bidirectional = bidirectional

        if mapping is None:
            # Default mapping
            self.mapping = {
                '<pad>': 0,
                '<sos>': 1,
                '<eos>': 2,
                '<sep>': 3,
            }
        else:
            self.mapping = mapping

        if type(embedding) is not str:
            self.embedding = embedding
        elif embedding == 'noisy_embeddings':
            self.embedding = NoisyEmbedding(
                vocab_size, 
                embedding_dim, 
                padding_idx,
                max_norm = 1 if norm_embeddings else None,
                noise_scale = embeddings_noise,
                dropout = emb_dropout,
                spatial_dropout = spatial_dropout,
            )
        else:
            self.embedding = nn.Embedding(
                vocab_size, 
                embedding_dim, 
                padding_idx,
            )

        if type(encoder) is not str:
            self.encoder = encoder
        elif encoder == 'lstm':
            self.encoder =  nn.LSTM(
                input_size = embedding_dim + 1 if use_truncated_text else embedding_dim, 
                hidden_size = hidden_dim, 
                num_layers = num_layers, 
                batch_first = batch_first, 
                dropout = dropout,
                bidirectional = bidirectional,
                proj_size = proj_size,
            )
        else:
            raise AttributeError(f'incorrect encoder parameter: '
                                f'`encoder` = "{encoder}"')
        
    def _forward_step_local(self, x: nn.utils.rnn.PackedSequence, enforce_sorted: bool = False):
        if self.use_truncated_text:
            x = unpack_sequence(x)
            x, x_counts = self.truncate_repeated_characters(x, normalize=True)
            x = pack_sequence(x, enforce_sorted=enforce_sorted)
            x_counts = pad_sequence(x_counts, batch_first=self.batch_first, padding_value=0)

        x, x_lengths = pad_packed_sequence(x, batch_first=self.batch_first)
        x = self.embedding(x) 

        if self.use_truncated_text:
            x = torch.cat([x, x_counts.unsqueeze(2)], dim=2)
        x = pack_padded_sequence(x, x_lengths, batch_first=self.batch_first, enforce_sorted=enforce_sorted)
        
        if isinstance(self.encoder, nn.LSTM):
            _, (last_hidden, _) = self.encoder(x)
            D, N, H = last_hidden.shape
            last_hidden = torch.transpose(last_hidden, 1, 0).reshape(N, -1)
        else:
            raise NotImplementedError('Outputs for other encoders are not implemented!')
        
        return last_hidden # seq_len, bidirect * num_layers * hidden_size (proj_size)
    
    def _convert_seq_to_global(self, x: nn.utils.rnn.PackedSequence):
        list_of_seq = unpack_sequence(x)
        seq_len = len(list_of_seq)
        list_of_seq[0] = torch.cat([torch.tensor([self.mapping['<sos>']]), list_of_seq[0]])
        list_of_seq[-1] = torch.cat([list_of_seq[-1], torch.tensor([self.mapping['<eos>']])])
        if seq_len > 1:
            list_of_seq[:-1] = [torch.cat([seq, torch.tensor([self.mapping['<sep>']])]) for seq in list_of_seq[:-1]]

        return torch.cat(list_of_seq), seq_len
    
    def _pooling_global(self, x: nn.utils.rnn.PackedSequence, x_lengths: List[int]):
        x = unpack_sequence(x)
        x = [nn.AdaptiveAvgPool2d((l, None))(s.unsqueeze(0))[0] for s, l in zip(x, x_lengths)]
        x = pad_sequence(x, batch_first=self.batch_first, padding_value=0)
        return x
    
    def _forward_step_global(self, x: List[nn.utils.rnn.PackedSequence], enforce_sorted: bool = False):
        x = [self._convert_seq_to_global(packed_seq) for packed_seq in x]
        x, seq_lengths = [seq[0] for seq in x], [seq[1] for seq in x]
        x = pack_sequence(x, enforce_sorted=enforce_sorted)
        x, x_lengths = pad_packed_sequence(x, batch_first=self.batch_first, padding_value=0)
        x = self.embedding(x)
        x = pack_padded_sequence(x, x_lengths, batch_first=self.batch_first, enforce_sorted=enforce_sorted)

        if isinstance(self.encoder, nn.LSTM):
            output, _ = self.encoder(x)
        else:
            raise NotImplementedError('Outputs for other encoders are not implemented!')
        
        output = self._pooling_global(output, seq_lengths)
        
        return output # B, T, H

    def forward(self, x: List[nn.utils.rnn.PackedSequence]):
        
        if self.encoder_type == 'local':
            x = [self._forward_step_local(packed_seq) for packed_seq in x]
            x = pad_sequence(x, padding_value=0, batch_first=self.batch_first)
            return x # B, H
        
        elif self.encoder_type == 'global':
            return self._forward_step_global(x) # B, T, H
    
    @property
    def output_size(self):
        if self.proj_size > 0:
            s = self.proj_size * self.num_layers * (self.bidirectional + 1)
        else:
            s = self.hidden_dim * self.num_layers * (self.bidirectional + 1)
        return s

    
    @staticmethod
    def truncate_repeated_characters(
        x: List[torch.tensor], 
        normalize: bool = False,
        ):
        """
        Truncates sequence with repeated characters
        Args:
            input: list of torch.tensor
            normalize: normalize counts by input lengths
        
        Example:
            >>> tensor_list = [torch.tensor([1, 5, 5, 5, 4, 5, 5, 7, 7, 2]), torch.tensor([1, 4, 4, 2])]
            >>> output_chars, output_counts = truncate_repeated_characters(tensor_list)
            >>> output_chars
            [tensor([1, 5, 4, 5, 7, 2]), tensor([1, 4, 2])]
            >>> output_counts
            [tensor([1, 3, 1, 2, 2, 1]), tensor([1, 2, 1])]
        """
        output_chars = []
        output_counts = []
        
        for tensor in x:
            chars = []
            counts = []
            count = 1
            prev_char = tensor[0]

            for char in tensor[1:]:
                if char == prev_char:
                    count += 1
                else:
                    chars.append(prev_char)
                    counts.append(count)
                    prev_char = char
                    count = 1

            chars.append(prev_char)
            counts.append(count)
            
            output_chars.append(torch.tensor(chars))
            output_counts.append(torch.tensor(counts))
        
        if normalize:
            output_counts = [out / len(seq) for out, seq in zip(output_counts, x)]

        return output_chars, output_counts