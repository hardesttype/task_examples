import dask.dataframe as dd
import numpy as np
from typing import List

from ptls.preprocessing.base import ColTransformer
from ptls.preprocessing.dask.col_transformer import ColTransformerDaskMixin


class TextTokenizer(ColTransformerDaskMixin, ColTransformer):
    """Text tokenizer

    Parameters
    ----------
    col_name_original:
        Source column name
    col_name_target:
        Target column name. Transformed column will be placed here
        If `col_name_target is None` then original column will be replaced by transformed values.
    is_drop_original_col:
        When target and original columns are different manage original col deletion.
    tokenizer:
        tokenizer
    """
    def __init__(self,
                 col_name_original: str,
                 col_name_target: str = None,
                 is_drop_original_col: bool = True,
                 tokenizer: object = None,
                 add_special_tokens: bool = True,
                 truncate_repeated_characters: bool = False,
                 ):
        super().__init__(
            col_name_original=col_name_original,
            col_name_target=col_name_target,
            is_drop_original_col=is_drop_original_col,
        )

        if tokenizer is None:
            self.tokenizer = SimpleTokenizer(
                add_special_tokens=add_special_tokens,
                truncate_repeated_characters=truncate_repeated_characters,
                )
        else:
            self.tokenizer = tokenizer

    def fit(self, x: dd.DataFrame):
        super().fit(x)
        pd_col = x[self.col_name_original].astype(str).fillna('')
        self.tokenizer.fit(pd_col)
        return self

    def transform(self, x: dd.DataFrame):
        pd_col = x[self.col_name_original].astype(str).fillna('')
        pd_col = pd_col.apply(self.tokenizer.encode)
            
        x = self.attach_column(x, pd_col)
        x = super().transform(x)
        return x
    
    @property
    def dictionary_size(self):
        return self.tokenizer.dictionary_size


class SimpleTokenizer():
    """Fit dictionary and tokenize text input

    Parameters
    ----------
    mapping:
        Dictionary with mapping from charecters to tokens
    add_special_tokens:
        Modifies `encode` function. If True: addes `<sos>` and `<eos>` tokens to a sequence
    """
    def __init__(self,
                 mapping: dict = None,
                 add_special_tokens: bool = True,
                 truncate_repeated_characters: bool = False):

        self.mapping = mapping
        self.add_special_tokens = add_special_tokens
        self.truncate_repeated = truncate_repeated_characters
        
    def fit(self, x: dd.Series):

        chars = x.astype(str).fillna('').apply(list).explode()

        vc = chars.value_counts()

        self.mapping = {k: i + 4 for i, k in enumerate(vc.index)}
        self.mapping['<pad>'] = 0
        self.mapping['<sos>'] = 1
        self.mapping['<eos>'] = 2
        self.mapping['<sep>'] = 3
        self.mapping['<unk>'] = len(vc) + 4

        return self
    
    def encode(self, text: str):

        tokens = [self.mapping.get(char, self.mapping['<unk>']) for char in text]

        if self.add_special_tokens:
            tokens = self._add_sos_eos_tokens(tokens)
        
        if self.truncate_repeated:
            tokens = self._truncate_repeated_characters([tokens])[0][0]

        return tokens
    
    @property
    def dictionary_size(self):
        return self.mapping['<unk>'] + 1
    
    def _add_sos_eos_tokens(self, tokens: list):
        return [self.mapping['<sos>']] + tokens + [self.mapping['<eos>']]
    
    @staticmethod
    def _truncate_repeated_characters(
        tokens: List[int], 
        normalize: bool = False,
        ):
        """
        Truncates sequence with repeated characters
        Args:
            input: list of torch.tensor
            normalize: normalize counts by input lengths
        
        Example:
            >>> tokens_list = [[1, 5, 5, 5, 4, 5, 5, 7, 7, 2], [1, 4, 4, 2]]
            >>> output_chars, output_counts = truncate_repeated_characters(tokens_list)
            >>> output_chars
            [[1, 5, 4, 5, 7, 2], [1, 4, 2]]
            >>> output_counts
            [[1, 3, 1, 2, 2, 1], [1, 2, 1]]
        """
        output_chars = []
        output_counts = []
        
        for tensor in tokens:
            chars = []
            counts = []
            count = 1
            prev_char = tensor[0]

            for char in tensor[1:]:
                if char == prev_char:
                    count += 1
                else:
                    chars.append(prev_char)
                    counts.append(count)
                    prev_char = char
                    count = 1

            chars.append(prev_char)
            counts.append(count)
            
            output_chars.append(chars)
            output_counts.append(counts)
        
        if normalize:
            output_counts = [out / len(seq) for out, seq in zip(output_counts, tokens)]

        return output_chars, output_counts
