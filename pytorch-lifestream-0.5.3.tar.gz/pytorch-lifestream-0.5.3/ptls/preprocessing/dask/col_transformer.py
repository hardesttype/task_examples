import dask.dataframe as dd


class ColTransformerDaskMixin:
    def check_is_col_exists(self, x: dd.DataFrame):
        if self.col_name_original not in x.columns:
            raise AttributeError(f'col_name_original="{self.col_name_original}" not in source dataframe. '
                                 f'Found {x.columns}')

    def drop_original_col(self, x: dd.DataFrame):
        if self.col_name_original != self.col_name_target and self.is_drop_original_col:
            x = x.drop(columns=self.col_name_original)
        return x

    @staticmethod
    def attach_column(df: dd.DataFrame, s: dd.Series):
        new_col_name = s.name
        cols = [col for col in df.columns if col != new_col_name]
        return dd.concat([df[cols], s.to_frame()], axis=1)
