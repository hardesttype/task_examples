from typing import List, Tuple
import torch
import numpy as np


class BucketingSampler(torch.utils.data.Sampler):
    """
    A sampler for torch.utils.data.Dataset that sorts the data into buckets based on sequence lengths.
    The sampler is designed to reduce padding by grouping sequences with similar lengths together.
    This can help to improve training efficiency by reducing the amount of computation required for padding.
    
    Args:
        dataset (torch.utils.data.Dataset): A dataset object with a 'seq_lengths' attribute.
        bucket_boundaries (List[Tuple[int, int]]): A list of tuples specifying the minimum and maximum
                                                  sequence lengths for each bucket.
        shuffle (bool, optional): Whether to shuffle the data within the buckets and the order of the buckets.
                                   Default is True.
    """

    def __init__(
            self, 
            dataset: torch.utils.data.Dataset, 
            bucket_boundaries: List[Tuple[int, int]],
            shuffle: bool = True,
        ):
        self.bucket_boundaries = bucket_boundaries
        self.buckets = self._create_buckets(dataset)
        self._len = len(dataset)
        self.shuffle = shuffle

    def _create_buckets(self, dataset):
        buckets = [[] for _ in range(len(self.bucket_boundaries))]
        seq_lengths = [dataset.get_seq_len(feature_dict) for feature_dict in dataset.data]
        for i, seq_len in enumerate(seq_lengths):
            for bucket_idx, (min_len, max_len) in enumerate(self.bucket_boundaries):
                if min_len <= seq_len <= max_len:
                    buckets[bucket_idx].append(i)
                    break
        return buckets

    def _shuffle_buckets(self):
        for bucket in self.buckets:
            np.random.shuffle(bucket)
        np.random.shuffle(self.buckets)

    def __iter__(self):
        if self.shuffle:
            self._shuffle_buckets()
        indices = [idx for bucket in self.buckets for idx in bucket]
        return iter(indices)

    def __len__(self):
        return len(self._len)
